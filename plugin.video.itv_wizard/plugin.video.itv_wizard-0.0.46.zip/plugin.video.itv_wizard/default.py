import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
import sys,plugintools
import zipfile
import json
import simplejson
import sys
import fileinput

base = 'http://infinitytv.ca/downloads/'
update_link = 'http://infinitytv.ca/downloads/update.zip'
full_restore_link = 'http://infinitytv.ca/downloads/full_restore.zip'
adult_full_restore_link = 'http://infinitytv.ca/downloads/adult_full_restore.zip'
adult_full_restore_fav_link = 'http://infinitytv.ca/downloads/adult_full_restore_fav.zip'
full_restore_fav_link = 'http://infinitytv.ca/downloads/full_restore_fav.zip'
build_versions_text = 'http://infinitytv.ca/downloads/build_versions.txt'
fav_xml = 'http://infinitytv.ca/downloads/favourites.xml'
media_url = 'http://infinitytv.ca/downloads/media.zip'
demo_url = 'http://infinitytv.ca/downloads/skin.infinitytv_demo.zip'
infinitytv_skin_url = 'http://infinitytv.ca/downloads/skin.infinitytv.zip'
itv_wizard_addon = 'plugin.video.itv_wizard'

USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
ADDON=xbmcaddon.Addon(id=itv_wizard_addon)

#########################################################################################################################################################

def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link

#########################################################################################################################################################

zip          =  ADDON.getSetting('zip')
dialog       =  xbmcgui.Dialog()
dp           =  xbmcgui.DialogProgress()
USERDATA     =  xbmc.translatePath(os.path.join('special://home/userdata',''))
ADDON_DATA   =  xbmc.translatePath(os.path.join(USERDATA,'addon_data'))
ADDONS       =  xbmc.translatePath(os.path.join('special://home','addons'))
GUI          =  xbmc.translatePath(os.path.join(USERDATA,'guisettings.xml'))
FAVS         =  xbmc.translatePath(os.path.join(USERDATA,'favourites.xml'))
FAVS2         =  xbmc.translatePath(os.path.join(USERDATA,'favourites2.xml'))
SOURCE       =  xbmc.translatePath(os.path.join(USERDATA,'sources.xml'))
ADVANCED     =  xbmc.translatePath(os.path.join(USERDATA,'advancedsettings.xml'))
RSS          =  xbmc.translatePath(os.path.join(USERDATA,'RssFeeds.xml'))
KEYMAPS      =  xbmc.translatePath(os.path.join(USERDATA,'keymaps','keyboard.xml'))
USB          =  xbmc.translatePath(os.path.join(zip))
skin         =  xbmc.getSkinDir()
HOME         =  xbmc.translatePath('special://home/')
infinitypath  =  xbmc.translatePath(os.path.join('special://home','addons',itv_wizard_addon))
skinspath  =  xbmc.translatePath(os.path.join('special://home','addons',itv_wizard_addon,'resources','skins'))
flag = xbmc.translatePath(os.path.join('special://home','addons',itv_wizard_addon,'flag.xml'))
demo       =  xbmc.translatePath(os.path.join('special://home','addons','skin.infinitytv_demo','addon.xml'))
media       =  xbmc.translatePath(os.path.join('special://home','media','launch.jpg'))
    
VERSION = "0.0.11"
PATH = "itv_wizard"

#########################################################################################################################################################

AddonID=itv_wizard_addon; AddonTitle="Total Wipe"
EXCLUDES=  [itv_wizard_addon,'skin.infinitytv_demo']
EXCLUDES_fav=  [itv_wizard_addon,'addon_data','skin.infinitytv_demo']
exclude_files_fav= ["favourites2.xml","xbmc.log","xbmc.old.log","kodi.log","kodi.old.log","app.jpg","launch.jpg","Splash.png"]
exclude_files_full= ["xbmc.log","xbmc.old.log","kodi.log","kodi.old.log","app.jpg","launch.jpg","Splash.png"]

def _get_keyboard( default="", heading="", hidden=False ):
    """ shows a keyboard and returns a value """
    keyboard = xbmc.Keyboard( default, heading, hidden )
    keyboard.doModal()
    if ( keyboard.isConfirmed() ):
        return unicode( keyboard.getText(), "utf-8" )
    return default

def ARCHIVE_CB(sourcefile, destfile, message_header, message1, message2, message3, exclude_dirs, exclude_files):
    zipobj = zipfile.ZipFile(destfile , 'w', zipfile.ZIP_DEFLATED)
    rootlen = len(sourcefile)
    for_progress = []
    ITEM =[]
    dp.create(message_header, message1, message2, message3)
    for base, dirs, files in os.walk(sourcefile):
        for file in files:
            ITEM.append(file)
    N_ITEM =len(ITEM)
    for base, dirs, files in os.walk(sourcefile):
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        files[:] = [f for f in files if f not in exclude_files]
        for file in files:
            for_progress.append(file) 
            progress = len(for_progress) / float(N_ITEM) * 100  
            dp.update(int(progress),"Backing up...",'[COLOR yellow]%s[/COLOR]'%file, 'Please wait')
            fn = os.path.join(base, file)
            if not 'temp' in dirs:
                if not itv_wizard_addon in dirs:
                   import time
                   FORCE= '01/01/1980'
                   FILE_DATE=time.strftime('%d/%m/%Y', time.gmtime(os.path.getmtime(fn)))
                   if FILE_DATE > FORCE:
                       zipobj.write(fn, fn[rootlen:])  
    zipobj.close()
    dp.close()

def WipeXBMC(name,url,description):
    choice = xbmcgui.Dialog().yesno("[COLOR red]VERY IMPORTANT: [/COLOR]", 'This will completely wipe your infinity tv box settings.', 'Would you like to create a backup before proceeding?', '', yeslabel='Yes',nolabel='No')
    if choice == 1:
        title = urllib.quote_plus("backup")
        backup_zip = xbmc.translatePath(os.path.join(infinitypath,title+'.zip'))
        exclude_dirs_full =  [itv_wizard_addon,'Thumbnails']
        exclude_files_full = ["xbmc.log","xbmc.old.log","kodi.log","kodi.old.log",'.DS_Store','.setup_complete','XBMCHelper.conf','Textures13.db']
        message_header = "Creating backup... "
        message1 = "This will be saved in the[CR]xbmc/addon/plugin.video.itv_wizard folder. "
        message2 = ""
        message3 = "Please wait"
        ARCHIVE_CB(HOME, backup_zip, message_header, message1, message2, message3, exclude_dirs_full, exclude_files_full)
            
    '''if skin!= "skin.confluence":
        dialog.ok('[B]itv wizard[/B]','[COLOR yellow]NOTICE: [/COLOR]You must switch to the Confluence skin to wipe. ','Please change to Confluence and try wiping again.','')
        xbmc.executebuiltin("ActivateWindow(appearancesettings)")
        return'''
    
    choice2 = xbmcgui.Dialog().yesno("[COLOR red]FINAL WARNING!!! [/COLOR]", 'Are you absolutely certain about wiping your infinity tv box settings?', '', 'All addons and userdata will be gone!', yeslabel='Yes',nolabel='No')
    if choice2 == 0:
        return
    elif choice2 == 1:
        total   = 0
        dp.create("[B]itv wizard[/B]","Wiping infinity tv Device...",'', 'Please wait')
        try:
            for root, dirs, files in os.walk(HOME,topdown=True):
                dirs[:] = [d for d in dirs if d not in EXCLUDES]
                for name in files:
                    percent = min(100 * total / name, 100)
                    try:
                        os.remove(os.path.join(root,name))
                        os.rmdir(os.path.join(root,name))
                        dp.update(percent)
                    except: pass
                        
                for name in dirs:
                    dp.update(percent)
                    try: os.rmdir(os.path.join(root,name)); os.rmdir(root)
                    except: pass
        except: pass
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    REMOVE_EMPTY_FOLDERS()
    dialog.ok('[B]itv wizard[/B]','Wipe complete! Please restart infinity tv box for changes to take effect.','','')
    return wizard(name,url,description)

def REMOVE_EMPTY_FOLDERS():
    print"########### Start Removing Empty Folders #########"
    empty_count = 0
    used_count = 0
    for curdir, subdirs, files in os.walk(HOME):
        if len(subdirs) == 0 and len(files) == 0: #check for empty directories. len(files) == 0 may be overkill
            empty_count += 1 #increment empty_count
            os.rmdir(curdir) #delete the directory
            print "successfully removed: "+curdir
        elif len(subdirs) > 0 and len(files) > 0: #check for used directories
            used_count += 1 #increment used_count

def backup_tool():
    choice = xbmcgui.Dialog().yesno("[COLOR yellow]itv wizard: [/COLOR]", 'Would you like to create a backup?.', 'Backup file will be stored in the plugin.video.itv_wizard folder.', '', yeslabel='Yes',nolabel='No')
    if choice == 1:
        title = urllib.quote_plus("backup")
        backup_zip = xbmc.translatePath(os.path.join(infinitypath,title+'.zip'))
        exclude_dirs_full =  [itv_wizard_addon,'Thumbnails']
        exclude_files_full = ["xbmc.log","xbmc.old.log","kodi.log","kodi.old.log",'.DS_Store','.setup_complete','XBMCHelper.conf','Textures13.db']
        message_header = "Creating backup... "
        message1 = "This will be saved in the[CR]xbmc/addon/plugin.video.itv_wizard folder. "
        message2 = ""
        message3 = "Please wait"
        ARCHIVE_CB(HOME, backup_zip, message_header, message1, message2, message3, exclude_dirs_full, exclude_files_full)
        dialog.ok('[B]itv wizard[/B]','Backup complete!','','')
    else:
        return

def Supportpopup():
    link = OPEN_URL(build_versions_text).replace('\n','').replace('\r','')
    match = re.compile('update="(.+?)".+?ull_restore="(.+?)".+?dult_full_restore="(.+?)".+?upport_full_restore="(.+?)".+?upport_update="(.+?)"').findall(link)
    for update,fr,afr,sfr,su in match:
        update_build = update
        latest_FR_build = fr
        latest_AFR_build = afr
        support_full1 = sfr
        support_update1 = su
       
        support_name =      '[COLOR blue]Name: [/COLOR]Infinity TV'
        support_website =   '[COLOR blue]Website: [/COLOR]www.infinitytv.ca'
        support_website2 =  '[COLOR blue]Support: [/COLOR]support@infinitytv.ca / www.itvforum.ca'
        support_full =      '[COLOR blue]Last full restore release :[/COLOR] ' + support_full1
        support_update =    '[COLOR blue]Last update release :[/COLOR] ' + support_update1
        support_facebook =  '[COLOR blue]Facebook:[/COLOR] facebook.com/myinfinitytv'
        dialog.ok('[B]Infinity tv info[/B]',support_website,support_website2,support_facebook+'[CR]'+support_full+'[CR]'+support_update)


#########################################################################################################################################################
wipe_icon = xbmc.translatePath(os.path.join(skinspath,'wipe.png'))
support_icon = xbmc.translatePath(os.path.join(skinspath,'support.png'))
fanart_background = xbmc.translatePath(os.path.join(skinspath,'fanart.jpg'))
restore_icon = xbmc.translatePath(os.path.join(skinspath,'restore.png'))
backup_icon = xbmc.translatePath(os.path.join(skinspath,'backup.png'))
fullrestore_icon = xbmc.translatePath(os.path.join(skinspath,'full_restore.png'))
adultfullrestore_icon = xbmc.translatePath(os.path.join(skinspath,'adult_full_restore.png'))
update_icon = xbmc.translatePath(os.path.join(skinspath,'updates.png'))
restore_backup_icon = xbmc.translatePath(os.path.join(skinspath,'restore_backup.png'))
stepone_icon = xbmc.translatePath(os.path.join(skinspath,'stepone.png'))
steptwo_icon = xbmc.translatePath(os.path.join(skinspath,'steptwo.png'))
stepthree_icon = xbmc.translatePath(os.path.join(skinspath,'stepthree.png'))
fix_icon = xbmc.translatePath(os.path.join(skinspath,'fixes.png'))
    
def CATEGORIES():
    #dialog = xbmcgui.Dialog()
    #dialog.ok("ITV Wizard","[COLOR yellow]Important![/COLOR]", "",'If you get any weird pop-ups saying "Addon is broken" or " dependencies not met" just click NO to them.')
    
    action_='<favourites>\n'
    f = open(flag, mode='w')
    f.write(action_)
    f.close()
    
    if not(os.path.isfile(media)):
        url = media_url
        name = 'media'
        path = xbmc.translatePath(os.path.join('special://home/addons',itv_wizard_addon))
        lib=os.path.join(path, name+'.zip')
        try:
           os.remove(lib)
        except:
           pass
        downloader.download(url, lib)
        addonfolder = xbmc.translatePath(os.path.join('special://home','media'))
        time.sleep(2)
        extract.all(lib,addonfolder)
        

    if not(os.path.isfile(demo)):
        url = demo_url
        name = 'skin.infinitytv_demo'
        path = xbmc.translatePath(os.path.join('special://home/addons',itv_wizard_addon))
        dp = xbmcgui.DialogProgress()
        dp.create("ITV Wizard","Quick Update... ",'', 'Please wait')
        lib=os.path.join(path, name+'.zip')
        try:
           os.remove(lib)
        except:
           pass
        downloader.download(url, lib, dp)
        addonfolder = xbmc.translatePath(os.path.join('special://home','addons'))
        time.sleep(2)
        dp.update(0,"", "Installing...")
        extract.all(lib,addonfolder,dp)
        dp.update(0,"", "Finishing up...")
        time.sleep(5)
        try:
           os.remove(lib)
        except:
           pass
        dialog = xbmcgui.Dialog()
        dialog.ok("ITV Wizard", "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish update. [/COLOR]")
        
        
    
    link = OPEN_URL(build_versions_text).replace('\n','').replace('\r','')
    match = re.compile('update="(.+?)".+?ull_restore="(.+?)".+?dult_full_restore="(.+?)".+?upport_full_restore="(.+?)".+?upport_update="(.+?)"').findall(link)
    for update,fr,afr,sfr,su in match:
        update_build = update
        latest_FR_build = fr
        latest_AFR_build = afr
        print update_build
        print latest_FR_build
        print latest_AFR_build
        print '###############################################################################################################################################'
        addDir('Support Info',update_link,3,support_icon,fanart_background,'Support info from your TV box seller. ')
        addDir('Update ' + '[COLOR orange]Latest Update '+update_build+'[/COLOR]',update_link,1,update_icon,fanart_background,'Update your box')
        addDir2('Full Restore ' + '[COLOR orange]Latest Build '+latest_FR_build+'[/COLOR]',full_restore_link,9,fullrestore_icon,fanart_background,'All addons and userdata will be completely wiped!')
        addDir2('Adult Full Restore ' + '[COLOR orange]Latest Build '+latest_AFR_build+'[/COLOR]',adult_full_restore_link,10,adultfullrestore_icon,fanart_background,'All addons and userdata will be completely wiped!')
        #addDir2('Skin Fix',update_link,11,fix_icon,fanart_background,'All addons and userdata will be completely wiped!')
        #addDir('Backup',update_link,5,backup_icon,fanart_background,'Backup your build ')
        #addDir('Restore backup',update_link,4,restore_backup_icon,fanart_background,'Restore your backup from complete wipe. ')
        setView('movies', 'MAIN')

def fix2(name,url,description):    
    url = infinitytv_skin_url
    name = 'skin.infinitytv'
    path = xbmc.translatePath(os.path.join('special://home/addons',itv_wizard_addon))
    dp = xbmcgui.DialogProgress()
    dp.create("ITV Wizard","Fixing skin issues... ",'', 'Please wait')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://home','addons'))
    time.sleep(2)
    dp.update(0,"", "Installing...")
    extract.all(lib,addonfolder,dp)
    dp.update(0,"", "Finishing up...")
    time.sleep(5)
    dialog = xbmcgui.Dialog()
    dialog.ok("ITV Wizard", "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish update. [/COLOR]")

def fix1(name,url,description):
    dialog = xbmcgui.Dialog()
    dialog.ok("ITV Wizard", "[COLOR blue]Please press YES on the next popup. [/COLOR]","","Then move to STEP TWO!")
    setSetting('lookandfeel.skin', 'skin.infinitytv_demo')

def fix(name,url,description):            
    addDir('STEP ONE',infinitytv_skin_url,12,stepone_icon,fanart_background,'All addons and userdata will be completely wiped!')
    addDir('STEP TWO',infinitytv_skin_url,13,steptwo_icon,fanart_background,'All addons and userdata will be completely wiped!')
    setView('movies', 'MAIN')
    

def Full_Restore_Steps(name,url,description):
    setting = 'lookandfeel.skin'
    skin = getSetting(setting)

    if (os.path.isfile(flag)):
        dialog = xbmcgui.Dialog()
        dialog.ok("ITV Wizard", "[COLOR blue]Please press Ok and then Click on Step 1, and follow the next prompts![/COLOR]")
            
    addDir('STEP ONE',full_restore_link,7,stepone_icon,fanart_background,'All addons and userdata will be completely wiped!')
    addDir('STEP TWO',full_restore_link,6,steptwo_icon,fanart_background,'All addons and userdata will be completely wiped!')
    addDir('STEP THREE',full_restore_link,8,stepthree_icon,fanart_background,'All addons and userdata will be completely wiped!')
    setView('movies', 'MAIN')

def Adult_Full_Restore_Steps(name,url,description):
    if (os.path.isfile(flag)):
        dialog = xbmcgui.Dialog()
        dialog.ok("ITV Wizard", "[COLOR blue]Please press Ok and then Click on Step 1, and follow the next prompts![/COLOR]")
        
    addDir('STEP ONE',adult_full_restore_link,7,stepone_icon,fanart_background,'All addons and userdata will be completely wiped!')
    addDir('STEP TWO',adult_full_restore_link,6,steptwo_icon,fanart_background,'All addons and userdata will be completely wiped!')
    addDir('STEP THREE',adult_full_restore_link,8,stepthree_icon,fanart_background,'All addons and userdata will be completely wiped!')
    setView('movies', 'MAIN')

def switchToconfluence():
    try:
       os.remove(flag)
    except:
       pass
    dialog = xbmcgui.Dialog()
    dialog.ok("ITV Wizard", "[COLOR blue]Please press YES on the next popup. [/COLOR]","","Then move to STEP TWO!")
    setSetting('lookandfeel.skin', 'skin.infinitytv_demo')

def reloadskin():
    xbmc.executebuiltin('ReloadSkin()')
    

def setSetting(setting, value):
    setting = '"%s"' % setting

    if isinstance(value, list):
        text = ''
        for item in value:
            text += '"%s",' % str(item)

        text  = text[:-1]
        text  = '[%s]' % text
        value = text

    elif not isinstance(value, int):
        value = '"%s"' % value

    query = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}' % (setting, value)
    xbmc.executeJSONRPC(query)

def getSetting(setting):
  
        import json
        setting = '"%s"' % setting
 
        query = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}' % (setting)
        response = xbmc.executeJSONRPC(query)

        response = json.loads(response)                

        if response.has_key('result'):
            if response['result'].has_key('value'):
                return response ['result']['value']
        
      
def wizard(name,url,description):
    
    path = xbmc.translatePath(os.path.join('special://home/addons',itv_wizard_addon))
    dp = xbmcgui.DialogProgress()
    dp.create("ITV Wizard","Downloading... ",'', 'Please wait')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    #READ_ZIP(lib)
    time.sleep(2)
    dp.update(0,"", "Installing...")
    extract.all(lib,addonfolder,dp)
    dp.update(0,"", "Finishing up...")
    time.sleep(5)
    #xbmc.executebuiltin('UnloadSkin()')
    #time.sleep(2)
    #xbmc.executebuiltin('ReloadSkin()')
    #time.sleep(2)
    dialog = xbmcgui.Dialog()
    dialog.ok("ITV Wizard", "[COLOR blue]Installation nearly complete but one important step remains. [/COLOR]")
    dialog = xbmcgui.Dialog()
    dialog.ok("ITV Wizard", "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish setup. [/COLOR]")

def EXIT():
    try:
       os.remove(flag)
    except:
       pass


def Full_Wizard(name,url,description):
    dp = xbmcgui.DialogProgress()
    choice2 = xbmcgui.Dialog().yesno("[COLOR red]WARNING!!! [/COLOR]", 'By pressing [COLOR green]YES[/COLOR] you will restore ', 'your Infinity TV to the latest complete build.', '', yeslabel='YES',nolabel='NO')
    if choice2 == 0:
        setSetting('lookandfeel.skin', 'skin.infinitytv')
        return
    elif choice2 == 1:
        choice_fav = xbmcgui.Dialog().yesno("[COLOR yellow]Would you like to Save your Favorites? [/COLOR]", '-By pressing [COLOR green]YES[/COLOR] all your Favorites will be [COLOR green]saved[/COLOR]. ', '-If you press [COLOR red]NO[/COLOR] your Favorites will be [COLOR red]wiped[/COLOR]', '-Both options will restore your Infinity TV to the Latest Software Build.', yeslabel='YES',nolabel='NO')
        
        if choice_fav == 0:
            dp.create("[B]itv wizard[/B]","Wiping infinity tv device...",'', 'Please wait as it will take a few minutes')
            try:
                for root, dirs, files in os.walk(HOME,topdown=True):
                    dirs[:] = [d for d in dirs if d not in EXCLUDES]
                    files[:] = [f for f in files if f not in exclude_files_full]
                    for name in files:
                        try:
                            os.remove(os.path.join(root,name))
                            os.rmdir(os.path.join(root,name))
                        except: pass
                            
                    for name in dirs:
                        try: os.rmdir(os.path.join(root,name)); os.rmdir(root)
                        except: pass
            except: pass
            
            REMOVE_EMPTY_FOLDERS()
            REMOVE_EMPTY_FOLDERS()
            REMOVE_EMPTY_FOLDERS()
            REMOVE_EMPTY_FOLDERS()
            REMOVE_EMPTY_FOLDERS()
            REMOVE_EMPTY_FOLDERS()
            REMOVE_EMPTY_FOLDERS()
            #dialog = xbmcgui.Dialog()
            #dialog.ok('[B]itv wizard[/B]','Wipe complete! Please press ok to download the restore files.','','')
            time.sleep(2)
            path = xbmc.translatePath(os.path.join('special://home/addons',itv_wizard_addon))
            dp = xbmcgui.DialogProgress()
            dp.create("ITV Wizard","Wipe complete! Now Downloading... ",'', 'Please wait')
            
            lib=os.path.join(path, 'fullbackup.zip')
            try:
               os.remove(lib)
            except:
               pass
            downloader.download(url, lib, dp)
            addonfolder = xbmc.translatePath(os.path.join('special://','home'))
            time.sleep(2)
            dp.update(0,"", "Installing...")
            extract.all(lib,addonfolder,dp)
            dp.update(0,"", "Finishing up...")
            time.sleep(3)
            xbmc.executebuiltin('UpdateLocalAddons') 
            xbmc.executebuiltin("UpdateAddonRepos")
            time.sleep(2)
            dialog = xbmcgui.Dialog()
            dialog.ok("ITV Wizard", "[COLOR blue]Please press YES on next popup! [/COLOR]","","Then Click on STEP THREE!")
            '''try:
               os.remove(lib)
            except:
               pass'''
            setSetting('lookandfeel.skin', 'skin.infinitytv')
            #dialog = xbmcgui.Dialog()
            #dialog.ok("ITV Wizard", "[COLOR blue]Installation is complete. [/COLOR]")
            
                    
        elif choice_fav == 1:
            
            ################################################################################################################################
            a = open(FAVS).read()
            f = open(FAVS2, mode='w')
            f.write(a)
            f.close()
            ################################################################################################################################
            
            dp.create("[B]itv wizard[/B]","Wiping infinity tv device...",'', 'Please wait as it will take a few minutes')
            try:
                for root, dirs, files in os.walk(HOME,topdown=True):
                    dirs[:] = [d for d in dirs if d not in EXCLUDES_fav]
                    files[:] = [f for f in files if f not in exclude_files_fav]
                    for name in files:
                        try:
                            os.remove(os.path.join(root,name))
                            os.rmdir(os.path.join(root,name))
                        except: pass
                            
                    for name in dirs:
                        try: os.rmdir(os.path.join(root,name)); os.rmdir(root)
                        except: pass
            except: pass

            REMOVE_EMPTY_FOLDERS()
            REMOVE_EMPTY_FOLDERS()
            REMOVE_EMPTY_FOLDERS()
            REMOVE_EMPTY_FOLDERS()
            REMOVE_EMPTY_FOLDERS()
            REMOVE_EMPTY_FOLDERS()
            REMOVE_EMPTY_FOLDERS()
            #dialog = xbmcgui.Dialog()
            #dialog.ok('[B]itv wizard[/B]','Wipe complete! Please press ok to download the restore files.','','')
            time.sleep(2)
            path = xbmc.translatePath(os.path.join('special://home/addons',itv_wizard_addon))
            dp = xbmcgui.DialogProgress()
            dp.create("ITV Wizard","Wipe complete! Now Downloading... ",'', 'Please wait')

            ####################################################################################################################
            cust_favorites()
            ####################################################################################################################
            
            lib=os.path.join(path, 'fullbackup.zip')
            try:
               os.remove(lib)
            except:
               pass
            if 'adult' in url:
                url = adult_full_restore_fav_link
                downloader.download(url, lib, dp)
                addonfolder = xbmc.translatePath(os.path.join('special://','home'))
                time.sleep(2)
                dp.update(0,"", "Installing...")
                extract.all(lib,addonfolder,dp)
                dp.update(0,"", "Finishing up...")
                time.sleep(3)
                xbmc.executebuiltin('UpdateLocalAddons') 
                xbmc.executebuiltin("UpdateAddonRepos")
                time.sleep(2)
                dialog = xbmcgui.Dialog()
                dialog.ok("ITV Wizard", "[COLOR blue]Please press YES on next popup! [/COLOR]","","Then Click on STEP THREE!")
                try:
                   os.remove(FAVS2)
                except:
                   pass
                setSetting('lookandfeel.skin', 'skin.infinitytv')
                #dialog = xbmcgui.Dialog()
                #dialog.ok("ITV Wizard", "[COLOR blue]Installation is complete. [/COLOR]")
                
            else:
                url = full_restore_fav_link
                downloader.download(url, lib, dp)
                addonfolder = xbmc.translatePath(os.path.join('special://','home'))
                time.sleep(2)
                dp.update(0,"", "Installing...")
                extract.all(lib,addonfolder,dp)
                dp.update(0,"", "Finishing up...")
                time.sleep(3)
                xbmc.executebuiltin('UpdateLocalAddons') 
                xbmc.executebuiltin("UpdateAddonRepos")
                time.sleep(2)
                dialog = xbmcgui.Dialog()
                dialog.ok("ITV Wizard", "[COLOR blue]Please press YES on next popup! [/COLOR]","","Then Click on STEP THREE!")
                try:
                   os.remove(FAVS2)
                except:
                   pass
                setSetting('lookandfeel.skin', 'skin.infinitytv')
                #dialog = xbmcgui.Dialog()
                #dialog.ok("ITV Wizard", "[COLOR blue]Installation is complete. [/COLOR]")
                
def GetFavourites():
    items = []
    json_query = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Favourites.GetFavourites", "params": {"type": null, "properties": ["path", "thumbnail", "window", "windowparameter"]}, "id": 1}')
    json_query = unicode(json_query, 'utf-8', errors='ignore')
    json_query = simplejson.loads(json_query)
    if json_query["result"]["limits"]["total"] > 0:
        for fav in json_query["result"]["favourites"]:
            path = GetFavPath(fav)
            newitem = {'Label': fav["title"],
                       'Thumb': fav["thumbnail"],
                       'Type': fav["type"],
                       'Builtin': path,
                       'Path': "plugin://script.extendedinfo/?info=action&&id=" + path}
            items.append(newitem)
    print "ITEMS ################################################"
    print items
    return items

def GetFavPath(fav):
    if fav["type"] == "media":
        path = "PlayMedia(%s)" % (fav["path"])
    elif fav["type"] == "script":
        path = "RunScript(%s)" % (fav["path"])
    else:
        path = "ActivateWindow(%s,%s)" % (
            fav["window"], fav["windowparameter"])
    return path

def GetFavouriteswithType(favtype):
    favs = GetFavourites()
    favlist = []
    for fav in favs:
        if fav["Type"] == favtype:
            favlist.append(fav)
    return favlist

def infinity_favorites():
    from t0mm0.common.net import Net
    import socket
    import time

    net = Net()

    path = xbmc.translatePath(os.path.join('special://home/addons',itv_wizard_addon))  
    lib=os.path.join(path, 'fullbackup.zip')
    import zipfile

    z = zipfile.ZipFile(lib, "r")
    for filename in z.namelist():
        if 'favourites.xml' in filename:
            a = z.read(filename)
            r='<favourite name="(.+?)" thumb="(.+?)">(.+?)</favourite>'
            
            match=re.compile(r).findall(a)
            print match
            for name,thumb,cmd in match:
                
                thumb=thumb.replace('thumb://None','/mnt/internal_sd/Android/data/org.xbmc.xbmc/files/.xbmc/addons/script.1channel.themepak/art/themes/Glossy_Black/favourites.png')
                cmd=cmd.replace('&quot;','').replace('&amp;','&')
                json.loads(xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Favourites.AddFavourite", "params": {"title":"%s", "type":"script", "path":"%s", "thumbnail":"%s"}, "id": 1}' % (name, cmd, thumb)))
                for i, line in enumerate(fileinput.input(FAVS, inplace=1)):
                    sys.stdout.write(line.replace('RunScript(&quot;','').replace('&quot;)',''))

        '''a = open(FAVS2).read()
        r='<favourite name="(.+?)" thumb="(.+?)">(.+?)</favourite>'
        match=re.compile(r).findall(a)
        for name1, thumb1, cmd1 in match:
            json.loads(xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Favourites.AddFavourite", "params": {"title":"%s", "type":"script", "path":"%s", "thumbnail":"%s"}, "id": 1}' % (name1, cmd1, thumb1)))
            for i, line in enumerate(fileinput.input(FAVS, inplace=1)):
                sys.stdout.write(line.replace('RunScript(&quot;','').replace('&quot;)',''))

                #return result'''
        
        
    
def cust_favorites():
    from t0mm0.common.net import Net
    import socket
    import time
    

    net = Net()
    action_=''
    f = open(FAVS, mode='w')
    f.write(action_)
    f.close()

    a = open(FAVS2).read()
    r='<favourite name="(.+?)" thumb="(.+?)">(.+?)</favourite>'
    match=re.compile(r).findall(a)
    for name1, thumb1, cmd1 in match:
        json.loads(xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Favourites.AddFavourite", "params": {"title":"%s", "type":"script", "path":"%s", "thumbnail":"%s"}, "id": 1}' % (name1, cmd1, thumb1)))
        for i, line in enumerate(fileinput.input(FAVS, inplace=1)):
            sys.stdout.write(line.replace('RunScript(&quot;','').replace('&quot;)','').replace('&amp;','&'))

    path = xbmc.translatePath(os.path.join('special://home/addons',itv_wizard_addon))  
    lib_fav=os.path.join(path, 'favourites.xml')
    downloader.download(fav_xml, lib_fav)
    time.sleep(2)
    filename = lib_fav
    
    r='<favourite name="(.+?)" thumb="(.+?)">(.+?)</favourite>'
    
    match2=re.compile(r).findall(a)
    for name,thumb,cmd in match2:
        a = open(FAVS).read()
        if name in a:break
            
            
        
        thumb=thumb.replace('thumb://None','/mnt/internal_sd/Android/data/org.xbmc.xbmc/files/.xbmc/addons/script.1channel.themepak/art/themes/Glossy_Black/favourites.png')
        cmd=cmd.replace('&quot;','')

        json.loads(xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Favourites.AddFavourite", "params": {"title":"%s", "type":"script", "path":"%s", "thumbnail":"%s"}, "id": 1}' % (name, cmd, thumb)))
        for i, line in enumerate(fileinput.input(FAVS, inplace=1)):
            sys.stdout.write(line.replace('RunScript(&quot;','').replace('&quot;)',''))


def RESTORE():

    import time
        
    try:
        dp = xbmcgui.DialogProgress()
        dp.create("ITV Wizard","Retrieving backup file... ",'', 'Please wait')
        lib=xbmc.translatePath(os.path.join(infinitypath,'backup.zip'))
        addonfolder = xbmc.translatePath(os.path.join('special://','home'))
        time.sleep(2)
        dp.update(0,"", "Installing...")
        extract.all(lib,addonfolder,dp)
        dp.update(0,"", "Finishing up...")
        time.sleep(5)
        dialog = xbmcgui.Dialog()
        dialog.ok("ITV Wizard", "[COLOR yellow]Installation nearly complete but one important step remains. [/COLOR]")
        dialog = xbmcgui.Dialog()
        dialog.ok("ITV Wizard", "[COLOR red]URGENT: Please unplug or power off your device immediately and then reboot to finish setup. [/COLOR]")
        
    except:
        dialog = xbmcgui.Dialog()
        dialog.ok('ITV Wizard','You need to backup your build first.\nTo backup your box press backup on main menu.','','')



def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

def addDir2(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        
       
        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
                      
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
        
        
if mode==None or url==None or len(url)<1:
        CATEGORIES()
       
elif mode==1:
        wizard(name,url,description)

elif mode==2:
        WipeXBMC(name,url,description)

elif mode==3:
        Supportpopup()

elif mode==4:
        RESTORE()

elif mode==5:
        backup_tool()

elif mode==6:
        Full_Wizard(name,url,description)

elif mode==7:
        switchToconfluence()

elif mode==8:
        dialog = xbmcgui.Dialog()
        dialog.ok("ITV Wizard","[COLOR yellow]Last Step![/COLOR]", "","Please press OK for all the changes to take place.")
        path = xbmc.translatePath(os.path.join('special://home/addons',itv_wizard_addon))        
        lib=os.path.join(path, 'fullbackup.zip')
        import zipfile
    
        z = zipfile.ZipFile(lib, "r")
        for filename in z.namelist():
            if 'guisettings.xml' in filename:
                a = z.read(filename)
                r='<setting type="(.+?)" name="%s.(.+?)">(.+?)</setting>'% skin
                
                match=re.compile(r).findall(a)
                print match
                for type,string,setting in match:
                    setting=setting.replace('&quot;','') .replace('&amp;','&') 
                    xbmc.executebuiltin("Skin.Set%s(%s,%s)"%(type.title(),string,setting))
        try:
           os.remove(lib)
        except:
           pass
        #xbmc.executebuiltin("XBMC.ActivateWindow(Home)")
        xbmc.executebuiltin('ReloadSkin()')

elif mode==9:
        Full_Restore_Steps(name,url,description)

elif mode==10:
        Adult_Full_Restore_Steps(name,url,description)

elif mode==11:
        fix(name,url,description)

elif mode==12:
        fix1(name,url,description)

elif mode==13:
        fix2(name,url,description)
        

        
xbmcplugin.endOfDirectory(int(sys.argv[1]))

