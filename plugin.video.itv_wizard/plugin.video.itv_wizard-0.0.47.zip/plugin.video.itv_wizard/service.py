import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
import sys,plugintools
import zipfile
import net
net=net.Net()

ADDON=xbmcaddon.Addon(id='plugin.video.itv_wizard')
THESITE = 'Infinitytv.ca'
zip          =  ADDON.getSetting('zip')
dialog       =  xbmcgui.Dialog()
dp           =  xbmcgui.DialogProgress()
USERDATA     =  xbmc.translatePath(os.path.join('special://home/userdata',''))
ADDON_DATA   =  xbmc.translatePath(os.path.join(USERDATA,'addon_data'))
ADDONS       =  xbmc.translatePath(os.path.join('special://home','addons'))
GUI          =  xbmc.translatePath(os.path.join(USERDATA,'guisettings.xml'))
FAVS         =  xbmc.translatePath(os.path.join(USERDATA,'favourites.xml'))
SOURCE       =  xbmc.translatePath(os.path.join(USERDATA,'sources.xml'))
ADVANCED     =  xbmc.translatePath(os.path.join(USERDATA,'advancedsettings.xml'))
RSS          =  xbmc.translatePath(os.path.join(USERDATA,'RssFeeds.xml'))
KEYMAPS      =  xbmc.translatePath(os.path.join(USERDATA,'keymaps','keyboard.xml'))
USB          =  xbmc.translatePath(os.path.join(zip))
skin         =  xbmc.getSkinDir()
HOME         =  xbmc.translatePath('special://home/')
AddonID      ='plugin.video.itv_wizard'; AddonTitle="Total Wipe"
EXCLUDES     =  ['plugin.video.itv_wizard','skin.infinitytv']
EXCLUDES_fav =  ['plugin.video.itv_wizard','skin.infinitytv','addon_data']

USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
ADDON=xbmcaddon.Addon(id='plugin.video.itv_wizard')
print "############################# before settings ######################################"
if ADDON.getSetting('user')=='':
    print "@@@@@@@@@@@@@@@@@@@@@@ after settings @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"
    dialog = xbmcgui.Dialog()
    if dialog.yesno(THESITE.upper(), "You need to enter your username and password", "Please visit ",THESITE.upper(),"Exit","Enter Details"):
        
        dialog.ok(THESITE.upper(), "You Now Need To Input", "Your Username")
        search_entered = ''
        keyboard = xbmc.Keyboard(search_entered, THESITE.upper())
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_entered = keyboard.getText() 
        ADDON.setSetting('user',search_entered)
        
        dialog.ok(THESITE.upper(), "You Now Need To Input", "Your Password")
        search_entered = ''
        keyboard = xbmc.Keyboard(search_entered, THESITE.upper())
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_entered = keyboard.getText() 
        ADDON.setSetting('pass',search_entered)
    else:
        xbmc.executebuiltin("XBMC.ActivateWindow(RestartApp)")

loginurl = 'http://infinitytv.ca/wizard-page/'
username = ADDON.getSetting('user')
password = ADDON.getSetting('pass')

data     = {'pwd': password,'log': username,'redirect_to': 'http://infinitytv.ca/wizard-page/','a':'login','Submit':'Log In'}
headers  = {'Host':'infinitytv.ca','Origin':'http://infinitytv.ca','Upgrade-Insecure-Requests':'1',
                                        'Referer':'http://infinitytv.ca/wizard-page/', 'Content-Type':'application/x-www-form-urlencoded',
                                                'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36'}

html = net.http_POST(loginurl, data, headers).content

try:
    if '<h2>Login Failed!</h2>' in html:
        print '################ Login Failed ######################################'
        dialog = xbmcgui.Dialog()
        dialog.ok("You entered the wrong details please try again", "Username : "+ADDON.getSetting('user'), "Password : "+ ADDON.getSetting('pass'), "is Wrong Please Visit "+THESITE.upper()+"")
        dialog.ok(THESITE.upper(), "You Now Need To Input", "Your Username")
        search_entered = ''
        keyboard = xbmc.Keyboard(search_entered, THESITE.upper())
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_entered = keyboard.getText() 
        ADDON.setSetting('user',search_entered)
        
        dialog.ok(THESITE.upper(), "You Now Need To Input", "Your Password")
        search_entered = ''
        keyboard = xbmc.Keyboard(search_entered, THESITE.upper())
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_entered = keyboard.getText() 
        ADDON.setSetting('pass',search_entered)
        
        if '<h2>Login Failed!</h2>' in html:
            print '################ Login Failed 1 ######################################'
            xbmc.executebuiltin('Quit')
        else:
            print '################ Login passed 1 ######################################'
            if ADDON.getSetting('start-wizard')=='0':
                name='fullbackup'
                url='http://infinitytv.ca/downloads/full_restore.zip'
                description=''
                choice2 = xbmcgui.Dialog().yesno("[COLOR yellow]Full 3rd Party build!!! [/COLOR]", 'Would you like InfinityTV to search for 3rd party content online?', ' Please beware Infinitytv does not have any affiliations with 3rd party online serach that might be illegal', '', yeslabel='YES',nolabel='NO')
                if choice2 == 0:
                    print '################ pressed No ######################################'
                    xbmc.executebuiltin("ActivateWindow(Home)")
                elif choice2 == 1:
                    print '################ pressed YES ######################################'
                    path = xbmc.translatePath(os.path.join('special://home/addons','plugin.video.itv_wizard'))
                    dp = xbmcgui.DialogProgress()
                    dp.create("ITV Wizard","Searching for online content... ",'', 'Please wait')
                    
                    lib=os.path.join(path, 'fullbackup.zip')
                    try:
                       os.remove(lib)
                    except:
                       pass
                    downloader.download(url, lib, dp)
                    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
                    time.sleep(2)
                    dp.update(0,"", "Installing...")
                    extract.all(lib,addonfolder,dp)
                    dp.update(0,"", "Finishing up...")
                    time.sleep(5)
                    ADDON.setSetting('start-wizard','1')
                    os.remove(lib)
                    dialog = xbmcgui.Dialog()
                    dialog.ok("ITV Wizard", "[COLOR blue]Installation nearly complete but one important step remains. [/COLOR]")
                    dialog = xbmcgui.Dialog()
                    dialog.ok("ITV Wizard", "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish setup. [/COLOR]")
            else:
                ADDON.setSetting('start-wizard','1')
                xbmc.executebuiltin("ActivateWindow(Home)")
         
    
    else:
        if ADDON.getSetting('start-wizard')=='0':
            print '################ Login passed 2 ######################################'
            choice2 = xbmcgui.Dialog().yesno("[COLOR yellow]Full 3rd Party build!!! [/COLOR]", 'Would you like InfinityTV to search 3rd party content online?', 'Infinitytv does not have any affiliations with online seraches that might be illegal', '', yeslabel='YES',nolabel='NO')
            if choice2 == 0:
                print '################ pressed No ######################################'
                xbmc.executebuiltin("ActivateWindow(Home)")
            elif choice2 == 1:
                dp = xbmcgui.DialogProgress()
                dp.create("ITV Wizard","Searching online content... ",'', 'Please wait')
                name='fullbackup'
                url='http://infinitytv.ca/downloads/full_restore.zip'
                description=''
                path = xbmc.translatePath(os.path.join('special://home/addons','plugin.video.itv_wizard'))
                lib=os.path.join(path, 'fullbackup.zip')
                print '################ pressed YES 2 ######################################'
                downloader.download(url, lib, dp)
                addonfolder = xbmc.translatePath(os.path.join('special://','home'))
                time.sleep(2)
                dp.update(0,"", "Installing...")
                extract.all(lib,addonfolder,dp)
                dp.update(0,"", "Finishing up...")
                time.sleep(5)
                ADDON.setSetting('start-wizard','1')
                os.remove(lib)
                dialog = xbmcgui.Dialog()
                dialog.ok("ITV Wizard", "[COLOR blue]Installation nearly complete but one important step remains. [/COLOR]")
                dialog = xbmcgui.Dialog()
                dialog.ok("ITV Wizard", "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish setup. [/COLOR]")
            
        else:
            ADDON.setSetting('start-wizard','1')
            xbmc.executebuiltin("ActivateWindow(Home)")
except:pass

