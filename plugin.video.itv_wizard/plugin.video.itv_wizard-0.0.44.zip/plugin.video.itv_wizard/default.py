ooOOOoo = ''
def ttTTtt(i, t1, t2=[]):
 t = ooOOOoo
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0  
 for c in t2:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t

import xbmc , xbmcaddon , xbmcgui , xbmcplugin , os
import shutil
import urllib2 , urllib
import re
import extract
import downloader
import time
import sys , plugintools
import zipfile
if 64 - 64: i11iIiiIii
OO0o = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
Oo0Ooo = ttTTtt(0,[104,0,116,218,116],[63,112,230,58,0,47,190,47,41,105,141,110,90,102,125,105,55,110,225,105,41,116,170,121,34,116,219,118,107,46,172,99,248,97,148,47,162,100,225,111,37,119,33,110,58,108,231,111,31,97,110,100,123,115,157,47])
O0O0OO0O0O0 = xbmcaddon . Addon ( id = ttTTtt(0,[112,160,108,237,117,28,103,78,105,129,110,226,46,34,118,103,105,242,100,51,101,74,111,117,46,53,105],[129,116,22,118,255,95,147,119,170,105,87,122,246,97,118,114,116,100]) )
if 5 - 5: iiI / ii1I
#########################################################################################################################################################
if 61 - 61: iII111iiiii11 % I1IiiI
def IIi1IiiiI1Ii ( url ) :
 I11i11Ii = urllib2 . Request ( url )
 I11i11Ii . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 oO00oOo = urllib2 . urlopen ( I11i11Ii )
 OOOo0 = oO00oOo . read ( )
 oO00oOo . close ( )
 return OOOo0
 if 54 - 54: i1 - o0 * i1oOo0OoO * iIIIiiIIiiiIi % Oo
o0O = ttTTtt(0,[104,12,116,59,116,194,112],[209,58,176,47,184,47,237,105,2,110,116,102,246,105,146,110,122,105,15,116,142,121,190,116,6,118,47,46,159,99,211,97,102,47,206,100,97,111,92,119,70,110,55,108,209,111,9,97,111,100,76,115,196,47,12,117,183,112,222,100,95,97,229,116,109,101,107,46,131,122,211,105,22,112])
IiiIII111iI = ttTTtt(70,[100,104,49,116,210,116,235,112],[110,58,4,47,19,47,227,105,165,110,94,102,123,105,62,110,116,105,47,116,199,121,76,116,27,118,215,46,131,99,245,97,194,47,36,100,233,111,226,119,243,110,32,108,46,111,61,97,78,100,176,115,194,47,91,102,100,117,241,108,253,108,20,95,220,114,164,101,89,115,178,116,202,111,214,114,35,101,80,46,173,122,137,105,217,112])
IiII = ttTTtt(91,[199,104,73,116,210,116,193,112,86,58,216,47,169,47,133,105],[203,110,107,102,180,105,241,110,229,105,178,116,190,121,21,116,195,118,20,46,178,99,102,97,77,47,124,100,34,111,22,119,75,110,230,108,150,111,185,97,164,100,206,115,190,47,233,97,213,100,132,117,1,108,138,116,140,95,47,102,51,117,31,108,179,108,43,95,16,114,66,101,226,115,146,116,120,111,44,114,230,101,186,46,165,122,8,105,185,112])
if 28 - 28: Ii11111i * iiI1i1
if 46 - 46: Ooo0OO0oOO * Ii * Oo0o
zip = O0O0OO0O0O0 . getSetting ( 'zip' )
OOO0o0o = xbmcgui . Dialog ( )
Ii1iI = xbmcgui . DialogProgress ( )
OoI1Ii11I1Ii1i = xbmc . translatePath ( os . path . join ( 'special://home/userdata' , '' ) )
Ooo = xbmc . translatePath ( os . path . join ( OoI1Ii11I1Ii1i , 'addon_data' ) )
o0oOoO00o = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
i1oOOoo00O0O = xbmc . translatePath ( os . path . join ( OoI1Ii11I1Ii1i , 'guisettings.xml' ) )
i1111 = xbmc . translatePath ( os . path . join ( OoI1Ii11I1Ii1i , 'favourites.xml' ) )
i11 = xbmc . translatePath ( os . path . join ( OoI1Ii11I1Ii1i , 'favourites2.xml' ) )
I11 = xbmc . translatePath ( os . path . join ( OoI1Ii11I1Ii1i , 'sources.xml' ) )
Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( OoI1Ii11I1Ii1i , 'advancedsettings.xml' ) )
oOo0oooo00o = xbmc . translatePath ( os . path . join ( OoI1Ii11I1Ii1i , 'RssFeeds.xml' ) )
oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( OoI1Ii11I1Ii1i , 'keymaps' , 'keyboard.xml' ) )
oo0o0O00 = xbmc . translatePath ( os . path . join ( zip ) )
oO = xbmc . getSkinDir ( )
i1iiIIiiI111 = xbmc . translatePath ( 'special://home/' )
oooOOOOO = ttTTtt(237,[136,104,67,116],[34,116,191,112,4,58,239,47,16,47,46,116,254,114,182,105,106,98,97,101,181,99,250,97,208,46,99,116,195,118,187,97,245,100,63,100,64,111,203,110,145,115,193,46,210,97,7,103,38,47])
i1iiIII111ii = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , 'plugin.video.itv_wizard' ) )
i1iIIi1 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , 'plugin.video.itv_wizard' , 'resources' , 'skins' ) )
ii11iIi1I = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , 'plugin.video.itv_wizard' , 'flag.xml' ) )
iI111I11I1I1 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , 'skin.infinitytv_demo' , 'addon.xml' ) )
OOooO0OOoo = xbmc . translatePath ( os . path . join ( 'special://home' , 'media' , 'launch.jpg' ) )
if 29 - 29: o00o / IiI1I1
OoO000 = "0.0.11"
IIiiIiI1 = "itv_wizard"
if 41 - 41: iiIIiIiIi
if 38 - 38: o0oooO0OO0O / Oooo
if 67 - 67: Ii / iII111iiiii11 % Oo0o - ii1I
OooO0o0Oo = 'plugin.video.itv_wizard' ; Oo00OOOOO = "Total Wipe"
O0O = [ 'plugin.video.itv_wizard' , 'skin.infinitytv_demo' ]
O00o0OO = [ 'plugin.video.itv_wizard' , 'addon_data' , 'skin.infinitytv_demo' ]
I11i1 = [ "favourites2.xml" , "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , "app.jpg" , "launch.jpg" , "Splash.png" ]
iIi1ii1I1 = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , "app.jpg" , "launch.jpg" , "Splash.png" ]
if 71 - 71: o0oooO0OO0O . iiI
def o0OO0oo0oOO ( default = "" , heading = "" , hidden = False ) :
 oo0oooooO0 = xbmc . Keyboard ( default , heading , hidden )
 if 19 - 19: Oo0o + Oooo
 oo0oooooO0 . doModal ( )
 if ( oo0oooooO0 . isConfirmed ( ) ) :
  return unicode ( oo0oooooO0 . getText ( ) , "utf-8" )
 return default
 if 53 - 53: iII111iiiii11 . I1IiiI
def ii1I1i1I ( sourcefile , destfile , message_header , message1 , message2 , message3 , exclude_dirs , exclude_files ) :
 OOoo0O0 = zipfile . ZipFile ( destfile , 'w' , zipfile . ZIP_DEFLATED )
 iiiIi1i1I = len ( sourcefile )
 oOO00oOO = [ ]
 OoOo = [ ]
 Ii1iI . create ( message_header , message1 , message2 , message3 )
 for Oo0Ooo , iI , o00O in os . walk ( sourcefile ) :
  for file in o00O :
   OoOo . append ( file )
 OOO0OOO00oo = len ( OoOo )
 for Oo0Ooo , iI , o00O in os . walk ( sourcefile ) :
  iI [ : ] = [ Iii111II for Iii111II in iI if Iii111II not in exclude_dirs ]
  o00O [ : ] = [ iiii11I for iiii11I in o00O if iiii11I not in exclude_files ]
  for file in o00O :
   oOO00oOO . append ( file )
   Ooo0OO0oOOii11i1 = len ( oOO00oOO ) / float ( OOO0OOO00oo ) * 100
   Ii1iI . update ( int ( Ooo0OO0oOOii11i1 ) , "Backing up..." , '[COLOR yellow]%s[/COLOR]' % file , 'Please wait' )
   IIIii1II1II = os . path . join ( Oo0Ooo , file )
   if not 'temp' in iI :
    if not 'plugin.video.itv_wizard' in iI :
     import time
     i1I1iI = '01/01/1980'
     oo0OooOOo0 = time . strftime ( '%d/%m/%Y' , time . gmtime ( os . path . getmtime ( IIIii1II1II ) ) )
     if oo0OooOOo0 > i1I1iI :
      OOoo0O0 . write ( IIIii1II1II , IIIii1II1II [ iiiIi1i1I : ] )
 OOoo0O0 . close ( )
 Ii1iI . close ( )
 if 92 - 92: IiI1I1 . Oo0o + Ii11111i
def IiII1I11i1I1I ( name , url , description ) :
 oO0Oo = xbmcgui . Dialog ( ) . yesno ( "[COLOR red]VERY IMPORTANT: [/COLOR]" , 'This will completely wipe your infinity tv box settings.' , 'Would you like to create a backup before proceeding?' , '' , yeslabel = 'Yes' , nolabel = 'No' )
 if oO0Oo == 1 :
  oOOoo0Oo = urllib . quote_plus ( "backup" )
  o00OO00OoO = xbmc . translatePath ( os . path . join ( i1iiIII111ii , oOOoo0Oo + '.zip' ) )
  OOOO0OOoO0O0 = [ 'plugin.video.itv_wizard' , 'Thumbnails' ]
  iIi1ii1I1 = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Textures13.db' ]
  O0Oo000ooO00 = "Creating backup... "
  oO0 = "This will be saved in the[CR]xbmc/addon/plugin.video.itv_wizard folder. "
  Ii1iIiII1ii1 = ""
  ooOooo000oOO = "Please wait"
  ii1I1i1I ( i1iiIIiiI111 , o00OO00OoO , O0Oo000ooO00 , oO0 , Ii1iIiII1ii1 , ooOooo000oOO , OOOO0OOoO0O0 , iIi1ii1I1 )
 if 59 - 59: i1 + iII111iiiii11 * Oo + I1IiiI
 if 58 - 58: i1 * Ii * iiI1i1 / Ii
 if 75 - 75: Ooo0OO0oOO
 if 50 - 50: o00o / i1oOo0OoO - Ooo0OO0oOO - Oo0o % IiI1I1 - Ooo0OO0oOO
 if 91 - 91: iIIIiiIIiiiIi / Oo0o - i1 . Oo0o
 if 18 - 18: Ii11111i
 O0o0O00Oo0o0 = xbmcgui . Dialog ( ) . yesno ( "[COLOR red]FINAL WARNING!!! [/COLOR]" , 'Are you absolutely certain about wiping your infinity tv box settings?' , '' , 'All addons and userdata will be gone!' , yeslabel = 'Yes' , nolabel = 'No' )
 if O0o0O00Oo0o0 == 0 :
  return
 elif O0o0O00Oo0o0 == 1 :
  O00O0oOO00O00 = 0
  Ii1iI . create ( "[B]itv wizard[/B]" , "Wiping infinity tv Device..." , '' , 'Please wait' )
  try :
   for i1Oo00 , iI , o00O in os . walk ( i1iiIIiiI111 , topdown = True ) :
    iI [ : ] = [ Iii111II for Iii111II in iI if Iii111II not in O0O ]
    for name in o00O :
     i1i = min ( 100 * O00O0oOO00O00 / name , 100 )
     try :
      os . remove ( os . path . join ( i1Oo00 , name ) )
      os . rmdir ( os . path . join ( i1Oo00 , name ) )
      Ii1iI . update ( i1i )
     except : pass
     if 50 - 50: iiIIiIiIi
    for name in iI :
     Ii1iI . update ( i1i )
     try : os . rmdir ( os . path . join ( i1Oo00 , name ) ) ; os . rmdir ( i1Oo00 )
     except : pass
  except : pass
 i11I1iIiII ( )
 i11I1iIiII ( )
 i11I1iIiII ( )
 i11I1iIiII ( )
 i11I1iIiII ( )
 i11I1iIiII ( )
 i11I1iIiII ( )
 OOO0o0o . ok ( '[B]itv wizard[/B]' , 'Wipe complete! Please restart infinity tv box for changes to take effect.' , '' , '' )
 return oO00o0 ( name , url , description )
 if 55 - 55: i1oOo0OoO + ii1I / Oo * Ooo0OO0oOO - i11iIiiIii - o00o
def i11I1iIiII ( ) :
 print "########### Start Removing Empty Folders #########"
 ii1ii1ii = 0
 oooooOoo0ooo = 0
 for I1I1IiI1 , III1iII1I1ii , o00O in os . walk ( i1iiIIiiI111 ) :
  if len ( III1iII1I1ii ) == 0 and len ( o00O ) == 0 :
   ii1ii1ii += 1
   os . rmdir ( I1I1IiI1 )
   print "successfully removed: " + I1I1IiI1
  elif len ( III1iII1I1ii ) > 0 and len ( o00O ) > 0 :
   oooooOoo0ooo += 1
   if 61 - 61: i1
def O0OOO ( ) :
 oO0Oo = xbmcgui . Dialog ( ) . yesno ( "[COLOR yellow]itv wizard: [/COLOR]" , 'Would you like to create a backup?.' , 'Backup file will be stored in the plugin.video.itv_wizard folder.' , '' , yeslabel = 'Yes' , nolabel = 'No' )
 if oO0Oo == 1 :
  oOOoo0Oo = urllib . quote_plus ( "backup" )
  o00OO00OoO = xbmc . translatePath ( os . path . join ( i1iiIII111ii , oOOoo0Oo + '.zip' ) )
  OOOO0OOoO0O0 = [ 'plugin.video.itv_wizard' , 'Thumbnails' ]
  iIi1ii1I1 = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Textures13.db' ]
  O0Oo000ooO00 = "Creating backup... "
  oO0 = "This will be saved in the[CR]xbmc/addon/plugin.video.itv_wizard folder. "
  Ii1iIiII1ii1 = ""
  ooOooo000oOO = "Please wait"
  ii1I1i1I ( i1iiIIiiI111 , o00OO00OoO , O0Oo000ooO00 , oO0 , Ii1iIiII1ii1 , ooOooo000oOO , OOOO0OOoO0O0 , iIi1ii1I1 )
  OOO0o0o . ok ( '[B]itv wizard[/B]' , 'Backup complete!' , '' , '' )
 else :
  return
  if 10 - 10: Ii * Oo0o % Oo / o0 / Oo
def iIIi1i1 ( ) :
 OOOo0 = IIi1IiiiI1Ii ( ttTTtt(768,[76,104,74,116,202,116,175,112,183,58,164,47,5,47],[48,105,56,110,52,102,177,105,25,110,41,105,90,116,174,121,107,116,16,118,70,46,70,99,11,97,219,47,78,100,208,111,149,119,109,110,41,108,172,111,56,97,150,100,93,115,173,47,223,98,179,117,40,105,158,108,110,100,230,95,208,118,30,101,207,114,194,115,238,105,239,111,248,110,189,115,239,46,8,116,221,120,99,116]) ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 i1IIIiiII1 = re . compile ( 'update="(.+?)".+?ull_restore="(.+?)".+?dult_full_restore="(.+?)".+?upport_full_restore="(.+?)".+?upport_update="(.+?)"' ) . findall ( OOOo0 )
 for OOOOoOoo0O0O0 , OOOo00oo0oO , IIiIi1iI , i1IiiiI1iI , i1iIi in i1IIIiiII1 :
  ooOOoooooo = OOOOoOoo0O0O0
  II1I = OOOo00oo0oO
  O0 = IIiIi1iI
  i1II1Iiii1I11 = i1IiiiI1iI
  IIII = i1iIi
  if 32 - 32: iII111iiiii11 / ii1I - Ii11111i
  o00oooO0Oo = '[COLOR blue]Name: [/COLOR]Infinity TV'
  o0O0OOO0Ooo = '[COLOR blue]Website: [/COLOR]www.infinitytv.ca'
  iiIiI = '[COLOR blue]Support: [/COLOR]support@infinitytv.ca / www.itvforum.ca'
  I1 = '[COLOR blue]Last full restore release :[/COLOR] ' + i1II1Iiii1I11
  OOO00O0O = '[COLOR blue]Last update release :[/COLOR] ' + IIII
  iii = '[COLOR blue]Facebook:[/COLOR] facebook.com/myinfinitytv'
  OOO0o0o . ok ( '[B]Infinity tv info[/B]' , o0O0OOO0Ooo , iiIiI , iii + '[CR]' + I1 + '[CR]' + OOO00O0O )
  if 90 - 90: Ii11111i % I1IiiI / iIIIiiIIiiiIi
  if 44 - 44: i1oOo0OoO . iIIIiiIIiiiIi / iiI1i1 + o00o
  if 65 - 65: iiI
oO00OOoO00 = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'wipe.png' ) )
IiI111111IIII = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'support.png' ) )
i1Ii = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'fanart.jpg' ) )
ii111iI1iIi1 = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'restore.png' ) )
OOO = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'backup.png' ) )
oo0OOo0 = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'full_restore.png' ) )
I11IiI = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'adult_full_restore.png' ) )
O0ooO0Oo00o = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'updates.png' ) )
ooO0oOOooOo0 = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'restore_backup.png' ) )
i1I1ii11i1Iii = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'stepone.png' ) )
I1IiiiiI = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'steptwo.png' ) )
o0OIiII = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'stepthree.png' ) )
ii1iII1II = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'fixes.png' ) )
if 48 - 48: i1 * o00o . Oo0o + Ooo0OO0oOO
def OoO0o ( ) :
 if 78 - 78: Ooo0OO0oOO % iiI % o00o
 if 46 - 46: iII111iiiii11 . i11iIiiIii
 if 94 - 94: Ii11111i * o00o / i1oOo0OoO / o00o
 oO0O0OO0O = '<favourites>\n'
 iiii11I = open ( ii11iIi1I , mode = 'w' )
 iiii11I . write ( oO0O0OO0O )
 iiii11I . close ( )
 if 81 - 81: Ooo0OO0oOO . Ii11111i % iiI / o0 - Ooo0OO0oOO
 if not ( os . path . isfile ( OOooO0OOoo ) ) :
  Ii1I1i = ttTTtt(55,[158,104,220,116,53,116,198,112,184,58,222,47,243,47],[153,105,221,110,55,102,205,105,124,110,254,105,18,116,172,121,130,116,41,118,82,46,43,99,85,97,213,47,123,100,116,111,222,119,80,110,174,108,221,111,93,97,56,100,127,115,212,47,26,109,15,101,94,100,233,105,11,97,3,46,253,122,23,105,148,112])
  OO = 'media'
  I1iI1ii1II = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'plugin.video.itv_wizard' ) )
  O0O0OOOOoo = os . path . join ( I1iI1ii1II , OO + '.zip' )
  try :
   os . remove ( O0O0OOOOoo )
  except :
   pass
  downloader . download ( Ii1I1i , O0O0OOOOoo )
  oOooO0 = xbmc . translatePath ( os . path . join ( 'special://home' , 'media' ) )
  time . sleep ( 2 )
  extract . all ( O0O0OOOOoo , oOooO0 )
  if 29 - 29: ii1I + Oo * iIIIiiIIiiiIi * Ii . o0 * o0
  if 7 - 7: iiIIiIiIi * o0oooO0OO0O % o00o - Ii11111i
 if not ( os . path . isfile ( iI111I11I1I1 ) ) :
  Ii1I1i = ttTTtt(0,[104],[140,116,141,116,237,112,46,58,215,47,56,47,108,105,147,110,126,102,60,105,153,110,235,105,111,116,102,121,158,116,38,118,151,46,161,99,176,97,88,47,156,100,245,111,153,119,152,110,180,108,115,111,239,97,88,100,53,115,24,47,73,115,41,107,226,105,11,110,157,46,190,105,116,110,171,102,80,105,63,110,133,105,127,116,255,121,2,116,93,118,251,95,65,100,45,101,197,109,211,111,221,46,238,122,184,105,155,112])
  OO = 'skin.infinitytv_demo'
  I1iI1ii1II = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'plugin.video.itv_wizard' ) )
  Ii1iI = xbmcgui . DialogProgress ( )
  Ii1iI . create ( "ITV Wizard" , "Quick Update... " , '' , 'Please wait' )
  O0O0OOOOoo = os . path . join ( I1iI1ii1II , OO + '.zip' )
  try :
   os . remove ( O0O0OOOOoo )
  except :
   pass
  downloader . download ( Ii1I1i , O0O0OOOOoo , Ii1iI )
  oOooO0 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
  time . sleep ( 2 )
  Ii1iI . update ( 0 , "" , "Installing..." )
  extract . all ( O0O0OOOOoo , oOooO0 , Ii1iI )
  Ii1iI . update ( 0 , "" , "Finishing up..." )
  time . sleep ( 5 )
  try :
   os . remove ( O0O0OOOOoo )
  except :
   pass
  OOO0o0o = xbmcgui . Dialog ( )
  OOO0o0o . ok ( "ITV Wizard" , "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish update. [/COLOR]" )
  if 13 - 13: o00o . i11iIiiIii
  if 56 - 56: iiI1i1 % iiI - o0
  if 100 - 100: o00o - iiI % Ooo0OO0oOO * Ii + o0
 OOOo0 = IIi1IiiiI1Ii ( ttTTtt(567,[75,104],[164,116,32,116,120,112,153,58,124,47,58,47,241,105,201,110,181,102,225,105,18,110,180,105,72,116,225,121,229,116,116,118,77,46,227,99,92,97,1,47,63,100,76,111,28,119,42,110,104,108,235,111,110,97,6,100,113,115,88,47,118,98,115,117,5,105,255,108,54,100,154,95,12,118,29,101,234,114,52,115,63,105,204,111,128,110,44,115,42,46,104,116,61,120,178,116]) ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 i1IIIiiII1 = re . compile ( 'update="(.+?)".+?ull_restore="(.+?)".+?dult_full_restore="(.+?)".+?upport_full_restore="(.+?)".+?upport_update="(.+?)"' ) . findall ( OOOo0 )
 for OOOOoOoo0O0O0 , OOOo00oo0oO , IIiIi1iI , i1IiiiI1iI , i1iIi in i1IIIiiII1 :
  ooOOoooooo = OOOOoOoo0O0O0
  II1I = OOOo00oo0oO
  O0 = IIiIi1iI
  print ooOOoooooo
  print II1I
  print O0
  print '###############################################################################################################################################'
  Oo0O0oooo ( 'Support Info' , o0O , 3 , IiI111111IIII , i1Ii , 'Support info from your TV box seller. ' )
  Oo0O0oooo ( 'Update ' + '[COLOR orange]Latest Update ' + ooOOoooooo + '[/COLOR]' , o0O , 1 , O0ooO0Oo00o , i1Ii , 'Update your box' )
  I111iI ( 'Full Restore ' + '[COLOR orange]Latest Build ' + II1I + '[/COLOR]' , IiiIII111iI , 9 , oo0OOo0 , i1Ii , 'All addons and userdata will be completely wiped!' )
  I111iI ( 'Adult Full Restore ' + '[COLOR orange]Latest Build ' + O0 + '[/COLOR]' , IiII , 10 , I11IiI , i1Ii , 'All addons and userdata will be completely wiped!' )
  if 56 - 56: o0
  if 54 - 54: o0oooO0OO0O / Ii . Ooo0OO0oOO % IiI1I1
  if 57 - 57: i11iIiiIii . iiI1i1 - o00o - Ooo0OO0oOO + Oo
  oO00oooOOoOo0 ( 'movies' , 'MAIN' )
  if 74 - 74: ii1I * iiI1i1 + Oo / I1IiiI / i1 . i1oOo0OoO
def oooOo0OOOoo0 ( name , url , description ) :
 url = ttTTtt(0,[104,18,116,81,116,153,112,159,58,20,47],[123,47,229,105,151,110,157,102,155,105,106,110,89,105,21,116,167,121,74,116,253,118,103,46,29,99,245,97,219,47,102,100,33,111,179,119,249,110,85,108,30,111,179,97,131,100,228,115,106,47,194,115,81,107,143,105,173,110,183,46,209,105,107,110,98,102,252,105,228,110,219,105,108,116,26,121,86,116,137,118,93,46,198,122,197,105,15,112])
 name = 'skin.infinitytv'
 I1iI1ii1II = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'plugin.video.itv_wizard' ) )
 Ii1iI = xbmcgui . DialogProgress ( )
 Ii1iI . create ( "ITV Wizard" , "Fixing skin issues... " , '' , 'Please wait' )
 O0O0OOOOoo = os . path . join ( I1iI1ii1II , name + '.zip' )
 try :
  os . remove ( O0O0OOOOoo )
 except :
  pass
 downloader . download ( url , O0O0OOOOoo , Ii1iI )
 oOooO0 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
 time . sleep ( 2 )
 Ii1iI . update ( 0 , "" , "Installing..." )
 extract . all ( O0O0OOOOoo , oOooO0 , Ii1iI )
 Ii1iI . update ( 0 , "" , "Finishing up..." )
 time . sleep ( 5 )
 OOO0o0o = xbmcgui . Dialog ( )
 OOO0o0o . ok ( "ITV Wizard" , "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish update. [/COLOR]" )
 if 51 - 51: i1oOo0OoO / Oo . Ii * Ii11111i + iIIIiiIIiiiIi * iiIIiIiIi
def OOOoOo ( name , url , description ) :
 OOO0o0o = xbmcgui . Dialog ( )
 OOO0o0o . ok ( "ITV Wizard" , "[COLOR blue]Please press YES on the next popup. [/COLOR]" , "" , "Then move to STEP TWO!" )
 O00o0 ( 'lookandfeel.skin' , 'skin.infinitytv_demo' )
 if 40 - 40: o0oooO0OO0O + iII111iiiii11 % Ii11111i - ii1I . o0
def iIiIi11iI ( name , url , description ) :
 Oo0O0oooo ( 'STEP ONE' , ttTTtt(429,[214,104,185,116,149,116,78,112,170,58],[226,47,255,47,196,105,109,110,7,102,51,105,234,110,56,105,236,116,39,121,137,116,14,118,208,46,227,99,232,97,15,47,61,100,133,111,215,119,81,110,201,108,87,111,170,97,42,100,68,115,154,47,108,115,250,107,155,105,200,110,179,46,121,105,85,110,202,102,186,105,61,110,7,105,181,116,27,121,231,116,195,118,243,46,154,122,183,105,101,112]) , 12 , i1I1ii11i1Iii , i1Ii , 'All addons and userdata will be completely wiped!' )
 Oo0O0oooo ( 'STEP TWO' , ttTTtt(429,[214,104,185,116,149,116,78,112,170,58],[226,47,255,47,196,105,109,110,7,102,51,105,234,110,56,105,236,116,39,121,137,116,14,118,208,46,227,99,232,97,15,47,61,100,133,111,215,119,81,110,201,108,87,111,170,97,42,100,68,115,154,47,108,115,250,107,155,105,200,110,179,46,121,105,85,110,202,102,186,105,61,110,7,105,181,116,27,121,231,116,195,118,243,46,154,122,183,105,101,112]) , 13 , I1IiiiiI , i1Ii , 'All addons and userdata will be completely wiped!' )
 oO00oooOOoOo0 ( 'movies' , 'MAIN' )
 if 83 - 83: i1 % i1oOo0OoO % Oooo % iiI1i1
 if 80 - 80: i11iIiiIii % Oooo + o00o % Oo0o - iiI1i1
def I1i1i1iii ( name , url , description ) :
 I1111i = 'lookandfeel.skin'
 oO = iIIii ( I1111i )
 if 92 - 92: o00o + Ooo0OO0oOO % Ii
 if ( os . path . isfile ( ii11iIi1I ) ) :
  OOO0o0o = xbmcgui . Dialog ( )
  OOO0o0o . ok ( "ITV Wizard" , "[COLOR blue]Please press Ok and then Click on Step 1, and follow the next prompts![/COLOR]" )
  if 62 - 62: iiI1i1 / I1IiiI
 Oo0O0oooo ( 'STEP ONE' , IiiIII111iI , 7 , i1I1ii11i1Iii , i1Ii , 'All addons and userdata will be completely wiped!' )
 Oo0O0oooo ( 'STEP TWO' , IiiIII111iI , 6 , I1IiiiiI , i1Ii , 'All addons and userdata will be completely wiped!' )
 Oo0O0oooo ( 'STEP THREE' , IiiIII111iI , 8 , o0OIiII , i1Ii , 'All addons and userdata will be completely wiped!' )
 oO00oooOOoOo0 ( 'movies' , 'MAIN' )
 if 98 - 98: I1IiiI / Oo0o
def i1ii1I1111ii1 ( name , url , description ) :
 if ( os . path . isfile ( ii11iIi1I ) ) :
  OOO0o0o = xbmcgui . Dialog ( )
  OOO0o0o . ok ( "ITV Wizard" , "[COLOR blue]Please press Ok and then Click on Step 1, and follow the next prompts![/COLOR]" )
  if 35 - 35: Oo / Ii11111i / o0oooO0OO0O
 Oo0O0oooo ( 'STEP ONE' , IiII , 7 , i1I1ii11i1Iii , i1Ii , 'All addons and userdata will be completely wiped!' )
 Oo0O0oooo ( 'STEP TWO' , IiII , 6 , I1IiiiiI , i1Ii , 'All addons and userdata will be completely wiped!' )
 Oo0O0oooo ( 'STEP THREE' , IiII , 8 , o0OIiII , i1Ii , 'All addons and userdata will be completely wiped!' )
 oO00oooOOoOo0 ( 'movies' , 'MAIN' )
 if 70 - 70: Ooo0OO0oOO
def oOOoO0o0oO ( ) :
 try :
  os . remove ( ii11iIi1I )
 except :
  pass
 OOO0o0o = xbmcgui . Dialog ( )
 OOO0o0o . ok ( "ITV Wizard" , "[COLOR blue]Please press YES on the next popup. [/COLOR]" , "" , "Then move to STEP TWO!" )
 O00o0 ( 'lookandfeel.skin' , 'skin.infinitytv_demo' )
 if 93 - 93: iiIIiIiIi * iII111iiiii11 + Oooo
def IiII111i1i11 ( ) :
 xbmc . executebuiltin ( 'ReloadSkin()' )
 if 40 - 40: Oooo * iiIIiIiIi * i11iIiiIii
 if 57 - 57: Oooo
def O00o0 ( setting , value ) :
 setting = '"%s"' % setting
 if 29 - 29: Oo - iiIIiIiIi * iII111iiiii11 + iII111iiiii11 . i1 + iII111iiiii11
 if isinstance ( value , list ) :
  O0o000Oo = ''
  for ooo in value :
   O0o000Oo += '"%s",' % str ( ooo )
   if 27 - 27: Oooo % o0
  O0o000Oo = O0o000Oo [ : - 1 ]
  O0o000Oo = '[%s]' % O0o000Oo
  value = O0o000Oo
  if 73 - 73: Ii
 elif not isinstance ( value , int ) :
  value = '"%s"' % value
  if 70 - 70: ii1I
 i11ii1iI = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}' % ( setting , value )
 xbmc . executeJSONRPC ( i11ii1iI )
 if 22 - 22: iII111iiiii11
def iIIii ( setting ) :
 if 75 - 75: Ii11111i + Ii11111i + I1IiiI - I1IiiI
 import json
 setting = '"%s"' % setting
 if 76 - 76: iIIIiiIIiiiIi . iiI % iiI - Ii11111i - ii1I - o0
 i11ii1iI = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}' % ( setting )
 oO00oOo = xbmc . executeJSONRPC ( i11ii1iI )
 if 53 - 53: I1IiiI
 oO00oOo = json . loads ( oO00oOo )
 if 59 - 59: Ii11111i
 if oO00oOo . has_key ( 'result' ) :
  if oO00oOo [ 'result' ] . has_key ( 'value' ) :
   return oO00oOo [ 'result' ] [ 'value' ]
   if 81 - 81: Oo - Oo . IiI1I1
   if 73 - 73: Oo0o % i11iIiiIii - o0
def oO00o0 ( name , url , description ) :
 if 7 - 7: iiI * i11iIiiIii * o00o + Oooo % iIIIiiIIiiiIi - Oooo
 I1iI1ii1II = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'plugin.video.itv_wizard' ) )
 Ii1iI = xbmcgui . DialogProgress ( )
 Ii1iI . create ( "ITV Wizard" , "Downloading... " , '' , 'Please wait' )
 O0O0OOOOoo = os . path . join ( I1iI1ii1II , name + '.zip' )
 try :
  os . remove ( O0O0OOOOoo )
 except :
  pass
 downloader . download ( url , O0O0OOOOoo , Ii1iI )
 oOooO0 = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
 if 39 - 39: i1oOo0OoO * Ii % Ii - iII111iiiii11 + Ii11111i - Oo0o
 time . sleep ( 2 )
 Ii1iI . update ( 0 , "" , "Installing..." )
 extract . all ( O0O0OOOOoo , oOooO0 , Ii1iI )
 Ii1iI . update ( 0 , "" , "Finishing up..." )
 time . sleep ( 5 )
 if 23 - 23: i11iIiiIii
 if 30 - 30: Ii11111i - I1IiiI % i1 + Oo0o * ii1I
 if 81 - 81: iiIIiIiIi % I1IiiI . ii1I
 if 4 - 4: i11iIiiIii % iIIIiiIIiiiIi % I1IiiI / iiIIiIiIi
 OOO0o0o = xbmcgui . Dialog ( )
 OOO0o0o . ok ( "ITV Wizard" , "[COLOR blue]Installation nearly complete but one important step remains. [/COLOR]" )
 OOO0o0o = xbmcgui . Dialog ( )
 OOO0o0o . ok ( "ITV Wizard" , "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish setup. [/COLOR]" )
 if 6 - 6: IiI1I1 / o0 % Ii - o0
def iiii111II ( ) :
 try :
  os . remove ( ii11iIi1I )
 except :
  pass
  if 50 - 50: Ii * o0 % ii1I + o00o + IiI1I1 + o0
  if 71 - 71: iiI1i1 * iiI1i1 * I1IiiI . Ooo0OO0oOO / o0oooO0OO0O
def ooo0O0o00O ( name , url , description ) :
 Ii1iI = xbmcgui . DialogProgress ( )
 O0o0O00Oo0o0 = xbmcgui . Dialog ( ) . yesno ( "[COLOR red]WARNING!!! [/COLOR]" , 'By pressing [COLOR green]YES[/COLOR] you will restore ' , 'your Infinity TV to the latest complete build.' , '' , yeslabel = 'YES' , nolabel = 'NO' )
 if O0o0O00Oo0o0 == 0 :
  O00o0 ( 'lookandfeel.skin' , 'skin.infinitytv' )
  return
 elif O0o0O00Oo0o0 == 1 :
  I1i11 = xbmcgui . Dialog ( ) . yesno ( "[COLOR yellow]Would you like to Save your Favorites? [/COLOR]" , '-By pressing [COLOR green]YES[/COLOR] all your Favorites will be [COLOR green]saved[/COLOR]. ' , '-If you press [COLOR red]NO[/COLOR] your Favorites will be [COLOR red]wiped[/COLOR]' , '-Both options will restore your Infinity TV to the Latest Software Build.' , yeslabel = 'YES' , nolabel = 'NO' )
  if 12 - 12: I1IiiI + I1IiiI - iiI1i1 * i1oOo0OoO % i1oOo0OoO - i1
  if I1i11 == 0 :
   Ii1iI . create ( "[B]itv wizard[/B]" , "Wiping infinity tv device..." , '' , 'Please wait as it will take a few minutes' )
   try :
    for i1Oo00 , iI , o00O in os . walk ( i1iiIIiiI111 , topdown = True ) :
     iI [ : ] = [ Iii111II for Iii111II in iI if Iii111II not in O0O ]
     o00O [ : ] = [ iiii11I for iiii11I in o00O if iiii11I not in iIi1ii1I1 ]
     for name in o00O :
      try :
       os . remove ( os . path . join ( i1Oo00 , name ) )
       os . rmdir ( os . path . join ( i1Oo00 , name ) )
      except : pass
      if 52 - 52: Oooo . IiI1I1 + o0oooO0OO0O
     for name in iI :
      try : os . rmdir ( os . path . join ( i1Oo00 , name ) ) ; os . rmdir ( i1Oo00 )
      except : pass
   except : pass
   if 38 - 38: I1IiiI - i1 . o0oooO0OO0O
   i11I1iIiII ( )
   i11I1iIiII ( )
   i11I1iIiII ( )
   i11I1iIiII ( )
   i11I1iIiII ( )
   i11I1iIiII ( )
   i11I1iIiII ( )
   if 58 - 58: o0 . IiI1I1 + Oo
   if 66 - 66: IiI1I1 / Ooo0OO0oOO * iII111iiiii11 + iII111iiiii11 % Oo0o
   time . sleep ( 2 )
   I1iI1ii1II = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'plugin.video.itv_wizard' ) )
   Ii1iI = xbmcgui . DialogProgress ( )
   Ii1iI . create ( "ITV Wizard" , "Wipe complete! Now Downloading... " , '' , 'Please wait' )
   if 49 - 49: Ooo0OO0oOO - i11iIiiIii . o0oooO0OO0O * o00o % IiI1I1 + I1IiiI
   O0O0OOOOoo = os . path . join ( I1iI1ii1II , 'fullbackup.zip' )
   try :
    os . remove ( O0O0OOOOoo )
   except :
    pass
   downloader . download ( url , O0O0OOOOoo , Ii1iI )
   oOooO0 = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
   time . sleep ( 2 )
   Ii1iI . update ( 0 , "" , "Installing..." )
   extract . all ( O0O0OOOOoo , oOooO0 , Ii1iI )
   Ii1iI . update ( 0 , "" , "Finishing up..." )
   time . sleep ( 5 )
   OOO0o0o = xbmcgui . Dialog ( )
   OOO0o0o . ok ( "ITV Wizard" , "[COLOR blue]Please press YES on next popup! [/COLOR]" , "" , "Then Click on STEP THREE!" )
   try :
    os . remove ( O0O0OOOOoo )
   except :
    pass
   O00o0 ( 'lookandfeel.skin' , 'skin.infinitytv' )
   if 71 - 71: Ii11111i
   if 38 - 38: Ooo0OO0oOO % Oo + iiI1i1 . i11iIiiIii
   if 53 - 53: i11iIiiIii * IiI1I1
   if 68 - 68: ii1I * ii1I . Ii11111i / i1 % i1oOo0OoO
  elif I1i11 == 1 :
   if 38 - 38: Oooo - Ii / IiI1I1
   if 66 - 66: iiI % iiI1i1 + i11iIiiIii . Oo / o00o + iiI1i1
   ooo00Ooo = open ( i1111 ) . read ( )
   iiii11I = open ( i11 , mode = 'w' )
   iiii11I . write ( ooo00Ooo )
   iiii11I . close ( )
   if 93 - 93: i11iIiiIii - o0 * iiI1i1 * Oo0o % iiI + iII111iiiii11
   if 25 - 25: iiIIiIiIi + o00o / Oooo . Ii11111i % iiI * iIIIiiIIiiiIi
   Ii1iI . create ( "[B]itv wizard[/B]" , "Wiping infinity tv device..." , '' , 'Please wait as it will take a few minutes' )
   try :
    for i1Oo00 , iI , o00O in os . walk ( i1iiIIiiI111 , topdown = True ) :
     iI [ : ] = [ Iii111II for Iii111II in iI if Iii111II not in O00o0OO ]
     o00O [ : ] = [ iiii11I for iiii11I in o00O if iiii11I not in I11i1 ]
     for name in o00O :
      try :
       os . remove ( os . path . join ( i1Oo00 , name ) )
       os . rmdir ( os . path . join ( i1Oo00 , name ) )
      except : pass
      if 84 - 84: Oooo % o00o + i11iIiiIii
     for name in iI :
      try : os . rmdir ( os . path . join ( i1Oo00 , name ) ) ; os . rmdir ( i1Oo00 )
      except : pass
   except : pass
   if 28 - 28: i1oOo0OoO + iIIIiiIIiiiIi * Ii % Ooo0OO0oOO . Oo0o % iiI
   i11I1iIiII ( )
   i11I1iIiII ( )
   i11I1iIiII ( )
   i11I1iIiII ( )
   i11I1iIiII ( )
   i11I1iIiII ( )
   i11I1iIiII ( )
   if 16 - 16: Oo0o - ii1I / o0 . i1 + ii1I
   if 19 - 19: iIIIiiIIiiiIi - i1oOo0OoO . iiI
   time . sleep ( 2 )
   I1iI1ii1II = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'plugin.video.itv_wizard' ) )
   Ii1iI = xbmcgui . DialogProgress ( )
   Ii1iI . create ( "ITV Wizard" , "Wipe complete! Now Downloading... " , '' , 'Please wait' )
   if 60 - 60: i1 + i1oOo0OoO
   if 9 - 9: Oooo * iII111iiiii11 - ii1I + Oo / iIIIiiIIiiiIi . iIIIiiIIiiiIi
   iiIIi ( )
   iiI1iI111ii1i ( )
   if 32 - 32: i1 * Oo % I1IiiI - IiI1I1 + ii1I + iiI1i1
   if 60 - 60: iiI1i1 % Oo * iIIIiiIIiiiIi % i1
   O0O0OOOOoo = os . path . join ( I1iI1ii1II , 'fullbackup.zip' )
   try :
    os . remove ( O0O0OOOOoo )
   except :
    pass
   if 'adult' in url :
    url = ttTTtt(683,[132,104,97,116,211,116,180,112],[134,58,25,47,206,47,232,105,140,110,107,102,22,105,108,110,47,105,221,116,81,121,237,116,2,118,152,46,119,99,224,97,154,47,67,100,160,111,25,119,179,110,231,108,79,111,116,97,40,100,127,115,198,47,92,97,100,100,129,117,63,108,212,116,143,95,32,102,12,117,24,108,238,108,178,95,126,114,210,101,159,115,207,116,41,111,237,114,65,101,113,95,5,102,0,97,2,118,95,46,213,122,112,105,179,112])
    downloader . download ( url , O0O0OOOOoo , Ii1iI )
    oOooO0 = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
    time . sleep ( 2 )
    Ii1iI . update ( 0 , "" , "Installing..." )
    extract . all ( O0O0OOOOoo , oOooO0 , Ii1iI )
    Ii1iI . update ( 0 , "" , "Finishing up..." )
    time . sleep ( 5 )
    OOO0o0o = xbmcgui . Dialog ( )
    OOO0o0o . ok ( "ITV Wizard" , "[COLOR blue]Please press YES on next popup! [/COLOR]" , "" , "Then Click on STEP THREE!" )
    try :
     os . remove ( O0O0OOOOoo ) ; os . remove ( i11 )
    except :
     pass
    O00o0 ( 'lookandfeel.skin' , 'skin.infinitytv' )
    if 70 - 70: iIIIiiIIiiiIi % Ooo0OO0oOO + Ii / o00o % iiI
    if 100 - 100: Ii11111i + Ii * Ii11111i
    try :
     os . remove ( O0O0OOOOoo ) ; os . remove ( i11 )
    except :
     pass
    return
   else :
    url = ttTTtt(0,[104,196,116,93,116,238,112,156,58,71,47,10,47,161,105,88,110,189,102,3,105],[128,110,8,105,168,116,67,121,187,116,136,118,55,46,49,99,205,97,42,47,175,100,8,111,32,119,56,110,163,108,47,111,96,97,225,100,157,115,143,47,16,102,48,117,12,108,82,108,222,95,215,114,137,101,56,115,196,116,119,111,28,114,174,101,207,95,168,102,236,97,137,118,19,46,241,122,17,105,47,112])
    downloader . download ( url , O0O0OOOOoo , Ii1iI )
    oOooO0 = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
    time . sleep ( 2 )
    Ii1iI . update ( 0 , "" , "Installing..." )
    extract . all ( O0O0OOOOoo , oOooO0 , Ii1iI )
    Ii1iI . update ( 0 , "" , "Finishing up..." )
    time . sleep ( 5 )
    OOO0o0o = xbmcgui . Dialog ( )
    OOO0o0o . ok ( "ITV Wizard" , "[COLOR blue]Please press YES on next popup! [/COLOR]" , "" , "Then Click on STEP THREE!" )
    try :
     os . remove ( O0O0OOOOoo ) ; os . remove ( i11 )
    except :
     pass
    O00o0 ( 'lookandfeel.skin' , 'skin.infinitytv' )
    if 80 - 80: Ii11111i * iiI - o00o
    if 66 - 66: i11iIiiIii - Ii * i1oOo0OoO
    try :
     os . remove ( O0O0OOOOoo ) ; os . remove ( i11 )
    except :
     pass
    return
    if 76 - 76: i11iIiiIii + Ii11111i / iiI1i1 - iIIIiiIIiiiIi - o00o + iiI1i1
def iiIIi ( ) :
 from t0mm0 . common . net import Net
 import socket
 import time
 if 51 - 51: ii1I . Oooo + ii1I
 oOoOO = Net ( )
 if 44 - 44: o0 / ii1I % Ooo0OO0oOO * iII111iiiii11 % Oooo
 oO0O0OO0O = '<favourites>\n'
 iiii11I = open ( i1111 , mode = 'w' )
 iiii11I . write ( oO0O0OO0O )
 iiii11I . close ( )
 if 25 - 25: iiI1i1 . Oooo
 iIIi = oOoOO . http_GET ( ttTTtt(754,[182,104],[96,116,34,116,20,112,76,58,209,47,217,47,37,105,159,110,109,102,127,105,53,110,180,105,17,116,12,121,43,116,70,118,125,46,156,99,132,97,38,47,185,100,4,111,121,119,169,110,111,108,234,111,166,97,236,100,71,115,42,47,97,102,235,97,133,118,133,111,38,117,79,114,235,105,121,116,23,101,192,115,22,46,98,120,192,109,167,108]) ) . content
 if 62 - 62: i1oOo0OoO - Oo0o
 for ooo in re . finditer ( r'<favourite name="(.+?)" thumb="(.+?)</favourite>' , iIIi , re . I ) :
  if 21 - 21: iiI % iiIIiIiIi . o0 / i1 + iiIIiIiIi
  OO = ooo . group ( 1 )
  OOOO0O00o = ooo . group ( 2 )
  if 62 - 62: ii1I
  if 12 - 12: Ii / Ii11111i
  try :
   oO0O0OO0O = '    <favourite name="%s" thumb="%s</favourite>\n' % ( OO , OOOO0O00o )
   if 42 - 42: i1oOo0OoO
   iiii11I = open ( i1111 , mode = 'a' )
   iiii11I . write ( oO0O0OO0O )
   iiii11I . close ( )
  except :
   continue
 if 19 - 19: Ooo0OO0oOO % iiI1i1 * ii1I + o0
 if 46 - 46: i1oOo0OoO
 if 1 - 1: IiI1I1
 if 97 - 97: Ii + IiI1I1 + iiI + i11iIiiIii
 if 77 - 77: Ii11111i / iII111iiiii11
 if 46 - 46: Ii11111i % ii1I . IiI1I1 % IiI1I1 + i11iIiiIii
def iiI1iI111ii1i ( ) :
 from t0mm0 . common . net import Net
 import socket
 import time
 if 72 - 72: ii1I * o00o % Oooo / iIIIiiIIiiiIi
 oOoOO = Net ( )
 if 35 - 35: Oooo + I1IiiI % iiI1i1 % Oo0o + Ooo0OO0oOO
 if 17 - 17: I1IiiI
 if 21 - 21: i1oOo0OoO
 if 29 - 29: Oo0o / i1 / Oooo * Ii
 if 10 - 10: o0oooO0OO0O % iiIIiIiIi * iiIIiIiIi . Oo0o / o00o % Ii
 if 49 - 49: iIIIiiIIiiiIi / Ooo0OO0oOO + iiI * Ii11111i
 ooo00Ooo = open ( i11 ) . read ( )
 I1ii11 = '<favourite name="(.+?)" thumb="(.+?)</favourite>'
 i1IIIiiII1 = re . compile ( I1ii11 ) . findall ( ooo00Ooo )
 print i1IIIiiII1
 for OO , OOOO0O00o in i1IIIiiII1 :
  if 74 - 74: i1oOo0OoO - Ii11111i . I1IiiI
  i1III = open ( i1111 ) . read ( )
  iii1Ii1Ii1 = '<favourite name="(.+?)" thumb="(.+?)</favourite>'
  IIi = re . compile ( iii1Ii1Ii1 ) . findall ( i1III )
  for ooO0oOo0o , OOii111IiiI1 in IIi :
   if OO or OOOO0O00o in ooO0oOo0o and OOii111IiiI1 :
    OO . replace ( ooO0oOo0o , '' )
    OOOO0O00o . replace ( ooO0oOo0o , '' )
    if 11 - 11: ii1I * o00o
   try :
    oO0O0OO0O = '    <favourite name="%s" thumb="%s</favourite>\n' % ( OO , OOOO0O00o )
    if 76 - 76: Oooo
    iiii11I = open ( i1111 , mode = 'a' )
    iiii11I . write ( oO0O0OO0O )
    iiii11I . close ( )
   except :
    continue
    if 15 - 15: Ii . Oo0o + iII111iiiii11 - iIIIiiIIiiiIi
 oO0O0OO0O = '</favourites>'
 iiii11I = open ( i1111 , mode = 'a' )
 iiii11I . write ( oO0O0OO0O )
 iiii11I . close ( )
 if 69 - 69: ii1I . iiI1i1 % Oooo + ii1I / iiI / iiI1i1
def O00OoOO0oo0 ( url ) :
 if 96 - 96: Oo . Ii11111i - Oooo
 import zipfile
 if 99 - 99: iiIIiIiIi . i1oOo0OoO - o00o % o00o * iiI . i1
 iIIII1iIIii = zipfile . ZipFile ( url , "r" )
 for oOOO00o000o in iIIII1iIIii . namelist ( ) :
  if 'guisettings.xml' in oOOO00o000o :
   if 9 - 9: Ooo0OO0oOO + Oo0o / Oo0o
   if 12 - 12: iII111iiiii11 % Ii11111i * Oo0o % ii1I / o00o
   pass
   if 27 - 27: i11iIiiIii % i1 % Oo0o . iiI - i1oOo0OoO + Oo
   if 57 - 57: ii1I / Oo0o - I1IiiI
  if 'favourites.xml' in oOOO00o000o :
   ooo00Ooo = iIIII1iIIii . read ( oOOO00o000o )
   iiii11I = open ( i1111 , mode = 'w' )
   iiii11I . write ( ooo00Ooo )
   iiii11I . close ( )
   if 51 - 51: iiIIiIiIi
  if 'sources.xml' in oOOO00o000o :
   ooo00Ooo = iIIII1iIIii . read ( oOOO00o000o )
   iiii11I = open ( I11 , mode = 'w' )
   iiii11I . write ( ooo00Ooo )
   iiii11I . close ( )
   if 25 - 25: iII111iiiii11 + iiIIiIiIi * iiI1i1
  if 'advancedsettings.xml' in oOOO00o000o :
   ooo00Ooo = iIIII1iIIii . read ( oOOO00o000o )
   iiii11I = open ( Oo0o0000o0o0 , mode = 'w' )
   iiii11I . write ( ooo00Ooo )
   iiii11I . close ( )
   if 92 - 92: o0 + Oo0o + iiI / Ii11111i + o0oooO0OO0O
  if 'RssFeeds.xml' in oOOO00o000o :
   ooo00Ooo = iIIII1iIIii . read ( oOOO00o000o )
   iiii11I = open ( oOo0oooo00o , mode = 'w' )
   iiii11I . write ( ooo00Ooo )
   iiii11I . close ( )
   if 18 - 18: Oooo * Oo . IiI1I1 / iiI1i1 / i11iIiiIii
  if 'keyboard.xml' in oOOO00o000o :
   ooo00Ooo = iIIII1iIIii . read ( oOOO00o000o )
   iiii11I = open ( oO0o0o0ooO0oO , mode = 'w' )
   iiii11I . write ( ooo00Ooo )
   iiii11I . close ( )
   if 21 - 21: Ooo0OO0oOO / iiI1i1 + o00o + iII111iiiii11
def OoOoI1iI11iIiIi1 ( ) :
 if 72 - 72: o0oooO0OO0O
 import time
 if 90 - 90: i1oOo0OoO % iiI * ii1I . IiI1I1
 try :
  Ii1iI = xbmcgui . DialogProgress ( )
  Ii1iI . create ( "ITV Wizard" , "Retrieving backup file... " , '' , 'Please wait' )
  O0O0OOOOoo = xbmc . translatePath ( os . path . join ( i1iiIII111ii , 'backup.zip' ) )
  oOooO0 = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
  time . sleep ( 2 )
  Ii1iI . update ( 0 , "" , "Installing..." )
  extract . all ( O0O0OOOOoo , oOooO0 , Ii1iI )
  Ii1iI . update ( 0 , "" , "Finishing up..." )
  time . sleep ( 5 )
  OOO0o0o = xbmcgui . Dialog ( )
  OOO0o0o . ok ( "ITV Wizard" , "[COLOR yellow]Installation nearly complete but one important step remains. [/COLOR]" )
  OOO0o0o = xbmcgui . Dialog ( )
  OOO0o0o . ok ( "ITV Wizard" , "[COLOR red]URGENT: Please unplug or power off your device immediately and then reboot to finish setup. [/COLOR]" )
  if 8 - 8: Oooo + i1 / IiI1I1 / Oo0o
 except :
  OOO0o0o = xbmcgui . Dialog ( )
  OOO0o0o . ok ( 'ITV Wizard' , 'You need to backup your build first.\nTo backup your box press backup on main menu.' , '' , '' )
  if 74 - 74: iiI / I1IiiI
  if 78 - 78: iII111iiiii11 . iIIIiiIIiiiIi + Oooo - I1IiiI
  if 31 - 31: iII111iiiii11 . Ii
def Oo0O0oooo ( name , url , mode , iconimage , fanart , description ) :
 O0iII1 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 II = True
 II1i = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 II1i . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 II1i . setProperty ( "Fanart_Image" , fanart )
 II = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O0iII1 , listitem = II1i , isFolder = False )
 return II
 if 2 - 2: ii1I * i1oOo0OoO % Ooo0OO0oOO - i1 - IiI1I1
def I111iI ( name , url , mode , iconimage , fanart , description ) :
 O0iII1 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 II = True
 II1i = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 II1i . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 II1i . setProperty ( "Fanart_Image" , fanart )
 II = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O0iII1 , listitem = II1i , isFolder = True )
 return II
 if 3 - 3: o0oooO0OO0O
 if 45 - 45: o0oooO0OO0O
 if 83 - 83: Oo . iII111iiiii11
def Oo0ooo ( ) :
 IIiIiiii = [ ]
 O0000OOO0 = sys . argv [ 2 ]
 if len ( O0000OOO0 ) >= 2 :
  ooo0 = sys . argv [ 2 ]
  oO000oOo00o0o = ooo0 . replace ( '?' , '' )
  if ( ooo0 [ len ( ooo0 ) - 1 ] == '/' ) :
   ooo0 = ooo0 [ 0 : len ( ooo0 ) - 2 ]
  O00oO0 = oO000oOo00o0o . split ( '&' )
  IIiIiiii = { }
  for O0Oo00OoOo in range ( len ( O00oO0 ) ) :
   ii1ii111 = { }
   ii1ii111 = O00oO0 [ O0Oo00OoOo ] . split ( '=' )
   if ( len ( ii1ii111 ) ) == 2 :
    IIiIiiii [ ii1ii111 [ 0 ] ] = ii1ii111 [ 1 ]
    if 33 - 33: iiI1i1
 return IIiIiiii
 if 92 - 92: iiIIiIiIi * i1oOo0OoO * i1oOo0OoO * o0 . ii1I
 if 16 - 16: Oooo % iII111iiiii11 - Ii * o00o * iiI1i1 / iII111iiiii11
ooo0 = Oo0ooo ( )
Ii1I1i = None
OO = None
I11o0oO00oO0o0o0 = None
I1I = None
ooooo = None
i11IIIiI1I = None
if 69 - 69: iiI
if 85 - 85: Oooo / iiI
try :
 Ii1I1i = urllib . unquote_plus ( ooo0 [ "url" ] )
except :
 pass
try :
 OO = urllib . unquote_plus ( ooo0 [ "name" ] )
except :
 pass
try :
 I1I = urllib . unquote_plus ( ooo0 [ "iconimage" ] )
except :
 pass
try :
 I11o0oO00oO0o0o0 = int ( ooo0 [ "mode" ] )
except :
 pass
try :
 ooooo = urllib . unquote_plus ( ooo0 [ "fanart" ] )
except :
 pass
try :
 i11IIIiI1I = urllib . unquote_plus ( ooo0 [ "description" ] )
except :
 pass
 if 18 - 18: Ii11111i % iiI * iiI1i1
 if 62 - 62: o0oooO0OO0O . iiIIiIiIi . iII111iiiii11
print str ( IIiiIiI1 ) + ': ' + str ( OoO000 )
print "Mode: " + str ( I11o0oO00oO0o0o0 )
print "URL: " + str ( Ii1I1i )
print "Name: " + str ( OO )
print "IconImage: " + str ( I1I )
if 11 - 11: Ii / Oo0o
if 73 - 73: I1IiiI / i11iIiiIii
def oO00oooOOoOo0 ( content , viewType ) :
 if 58 - 58: i1oOo0OoO . i1 + Ooo0OO0oOO - i11iIiiIii / i1 / iiI
 if content :
  xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , content )
 if O0O0OO0O0O0 . getSetting ( 'auto-view' ) == 'true' :
  xbmc . executebuiltin ( "Container.SetViewMode(%s)" % O0O0OO0O0O0 . getSetting ( viewType ) )
  if 85 - 85: Oo + Ii
  if 10 - 10: iiIIiIiIi / iIIIiiIIiiiIi + Oo / I1IiiI
if I11o0oO00oO0o0o0 == None or Ii1I1i == None or len ( Ii1I1i ) < 1 :
 OoO0o ( )
 if 27 - 27: o00o
elif I11o0oO00oO0o0o0 == 1 :
 oO00o0 ( OO , Ii1I1i , i11IIIiI1I )
 if 67 - 67: o0
elif I11o0oO00oO0o0o0 == 2 :
 IiII1I11i1I1I ( OO , Ii1I1i , i11IIIiI1I )
 if 55 - 55: iiI1i1 - IiI1I1 * Ii11111i + Oo * Oo * iiI
elif I11o0oO00oO0o0o0 == 3 :
 iIIi1i1 ( )
 if 91 - 91: o0oooO0OO0O - Ii % ii1I - iII111iiiii11 % Oooo
elif I11o0oO00oO0o0o0 == 4 :
 OoOoI1iI11iIiIi1 ( )
 if 98 - 98: iIIIiiIIiiiIi . iIIIiiIIiiiIi * Ooo0OO0oOO * i1 * o0oooO0OO0O
elif I11o0oO00oO0o0o0 == 5 :
 O0OOO ( )
 if 92 - 92: i1oOo0OoO
elif I11o0oO00oO0o0o0 == 6 :
 ooo0O0o00O ( OO , Ii1I1i , i11IIIiI1I )
 if 40 - 40: Oo / iiIIiIiIi
elif I11o0oO00oO0o0o0 == 7 :
 oOOoO0o0oO ( )
 if 79 - 79: iIIIiiIIiiiIi - ii1I + o00o - o0oooO0OO0O
elif I11o0oO00oO0o0o0 == 8 :
 OOO0o0o = xbmcgui . Dialog ( )
 OOO0o0o . ok ( "ITV Wizard" , "[COLOR yellow]Important![/COLOR]" , "" , "Please POWER DOWN your Infinity TV, and then turn it back ON for the changes to take place." )
 xbmc . executebuiltin ( "XBMC.ActivateWindow(Home)" )
 if 93 - 93: i1 . o0 - i1oOo0OoO + Oo
elif I11o0oO00oO0o0o0 == 9 :
 I1i1i1iii ( OO , Ii1I1i , i11IIIiI1I )
 if 61 - 61: i1
elif I11o0oO00oO0o0o0 == 10 :
 i1ii1I1111ii1 ( OO , Ii1I1i , i11IIIiI1I )
 if 15 - 15: i11iIiiIii % o0 * Oo0o / o0oooO0OO0O
elif I11o0oO00oO0o0o0 == 11 :
 iIiIi11iI ( OO , Ii1I1i , i11IIIiI1I )
 if 90 - 90: IiI1I1
elif I11o0oO00oO0o0o0 == 12 :
 OOOoOo ( OO , Ii1I1i , i11IIIiI1I )
 if 31 - 31: Ii + iiI
elif I11o0oO00oO0o0o0 == 13 :
 oooOo0OOOoo0 ( OO , Ii1I1i , i11IIIiI1I )
 if 87 - 87: Oooo
 if 45 - 45: iIIIiiIIiiiIi / iII111iiiii11 - IiI1I1 / o00o % iiIIiIiIi
 if 83 - 83: o0 . ii1I - iiIIiIiIi * i11iIiiIii
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
if 20 - 20: I1IiiI * o0oooO0OO0O + i1 % Ii11111i % Ooo0OO0oOO
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
