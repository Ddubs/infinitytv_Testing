ooOOOoo = ''
def ttTTtt(i, t1, t2=[]):
 t = ooOOOoo
 for c in t1:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0  
 for c in t2:
  t += chr(c)
  i += 1
  if i > 1:
   t = t[:-1]
   i = 0
 return t

import xbmc , xbmcaddon , xbmcgui , xbmcplugin , os
import shutil
import urllib2 , urllib
import re
import extract
import downloader
import time
import sys , plugintools
import zipfile
if 64 - 64: i11iIiiIii
OO0o = ttTTtt(110,[161,104,128,116,72,116,207,112],[164,58,36,47,42,47,177,105,200,110,205,102,8,105,30,110,128,105,107,116,138,121,57,116,89,118,52,46,146,99,130,97,24,47,77,100,185,111,216,119,206,110,13,108,145,111,122,97,105,100,240,115,101,47])
Oo0Ooo = ttTTtt(784,[148,104],[160,116,42,116,79,112,64,58,245,47,102,47,169,105,70,110,9,102,193,105,13,110,204,105,64,116,229,121,228,116,237,118,44,46,54,99,48,97,99,47,133,100,39,111,198,119,88,110,39,108,209,111,24,97,30,100,195,115,69,47,221,117,195,112,189,100,183,97,59,116,151,101,11,46,126,122,173,105,189,112])
O0O0OO0O0O0 = ttTTtt(193,[154,104,13,116],[162,116,26,112,200,58,0,47,5,47,146,105,187,110,129,102,34,105,245,110,243,105,167,116,8,121,228,116,248,118,108,46,40,99,109,97,215,47,118,100,222,111,226,119,58,110,191,108,128,111,202,97,207,100,162,115,10,47,23,102,188,117,5,108,96,108,11,95,98,114,10,101,92,115,240,116,186,111,208,114,148,101,112,46,248,122,67,105,72,112])
iiiii = ttTTtt(0,[104,61,116,14,116,33,112],[112,58,117,47,159,47,9,105,70,110,142,102,72,105,247,110,250,105,148,116,206,121,20,116,4,118,107,46,219,99,145,97,89,47,213,100,152,111,212,119,108,110,0,108,48,111,118,97,85,100,56,115,95,47,212,97,225,100,195,117,219,108,85,116,150,95,64,102,244,117,245,108,64,108,173,95,81,114,227,101,52,115,251,116,111,111,98,114,97,101,111,46,225,122,119,105,161,112])
ooo0OO = ttTTtt(488,[120,104],[255,116,184,116,141,112,213,58,113,47,199,47,49,105,149,110,77,102,242,105,55,110,255,105,120,116,227,121,231,116,95,118,253,46,222,99,178,97,59,47,96,100,155,111,129,119,119,110,224,108,16,111,208,97,181,100,209,115,98,47,51,97,79,100,139,117,205,108,136,116,68,95,243,102,234,117,4,108,90,108,114,95,168,114,87,101,36,115,65,116,212,111,133,114,130,101,118,95,94,102,21,97,74,118,157,46,48,122,30,105,1,112])
II1 = ttTTtt(0,[104,16,116],[21,116,21,112,156,58,50,47,81,47,170,105,43,110,231,102,20,105,71,110,178,105,141,116,129,121,245,116,251,118,241,46,15,99,71,97,90,47,226,100,213,111,139,119,149,110,196,108,178,111,109,97,215,100,129,115,164,47,45,102,241,117,198,108,129,108,98,95,35,114,159,101,89,115,81,116,125,111,191,114,144,101,166,95,190,102,116,97,169,118,14,46,190,122,164,105,99,112])
O00ooooo00 = ttTTtt(0,[104],[144,116,42,116,26,112,5,58,31,47,175,47,222,105,179,110,74,102,139,105,145,110,129,105,19,116,15,121,170,116,95,118,59,46,119,99,222,97,74,47,73,100,17,111,229,119,61,110,132,108,19,111,49,97,139,100,46,115,143,47,146,98,75,117,29,105,147,108,11,100,181,95,77,118,141,101,129,114,34,115,170,105,64,111,220,110,25,115,145,46,141,116,5,120,62,116])
I1IiiI = ttTTtt(744,[37,104,72,116,69,116,192,112,161,58,3,47,214,47,39,105,188,110,65,102,253,105,96,110],[166,105,171,116,59,121,161,116,15,118,243,46,188,99,173,97,93,47,229,100,175,111,101,119,72,110,84,108,198,111,18,97,176,100,235,115,139,47,131,102,237,97,175,118,234,111,224,117,227,114,26,105,30,116,65,101,209,115,50,46,26,120,189,109,108,108])
IIi1IiiiI1Ii = ttTTtt(703,[247,104,252,116,180,116,245,112,98,58],[181,47,209,47,116,105,63,110,73,102,117,105,238,110,64,105,150,116,185,121,137,116,183,118,137,46,253,99,184,97,30,47,18,100,138,111,74,119,243,110,251,108,52,111,21,97,89,100,211,115,216,47,54,109,209,101,35,100,90,105,12,97,121,46,119,122,225,105,33,112])
I11i11Ii = ttTTtt(1,[63,104,80,116,220,116,52,112,88,58],[189,47,120,47,111,105,43,110,203,102,39,105,245,110,89,105,149,116,122,121,51,116,54,118,189,46,149,99,66,97,77,47,234,100,108,111,243,119,232,110,113,108,72,111,75,97,151,100,6,115,18,47,216,115,221,107,250,105,149,110,175,46,3,105,144,110,135,102,223,105,135,110,99,105,170,116,178,121,81,116,115,118,237,95,4,100,104,101,238,109,167,111,160,46,102,122,246,105,204,112])
oO00oOo = ttTTtt(0,[104,245,116,176,116,217,112],[221,58,98,47,251,47,207,105,29,110,87,102,137,105,187,110,211,105,142,116,93,121,153,116,44,118,78,46,33,99,186,97,194,47,244,100,39,111,132,119,151,110,142,108,54,111,68,97,64,100,211,115,81,47,75,115,19,107,174,105,0,110,121,46,179,105,35,110,74,102,37,105,33,110,23,105,137,116,255,121,13,116,132,118,166,46,231,122,238,105,168,112])
OOOo0 = ttTTtt(320,[17,112,24,108,170,117,110,103,42,105,7,110],[87,46,100,118,77,105,172,100,4,101,54,111,146,46,233,105,24,116,22,118,62,95,80,119,142,105,222,122,27,97,171,114,231,100])
if 54 - 54: i1 - o0 * i1oOo0OoO * iIIIiiIIiiiIi % Oo
o0O = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
IiiIII111iI = xbmcaddon . Addon ( id = OOOo0 )
if 34 - 34: iii1I1I / O00oOoOoO0o0O . O0oo0OO0 + Oo0ooO0oo0oO . I1i1iI1i - II
#########################################################################################################################################################
if 100 - 100: i11Ii11I1Ii1i . ooO - OOoO / ooo0Oo0 * i1OOooo0000ooo - OOo000
def O0 ( url ) :
 I11i1i11i1I = urllib2 . Request ( url )
 I11i1i11i1I . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 Iiii = urllib2 . urlopen ( I11i1i11i1I )
 OOO0O = Iiii . read ( )
 Iiii . close ( )
 return OOO0O
 if 94 - 94: oooO0oOOOOo0o
 if 93 - 93: OoOoo0 % iii1I1I % O0oo0OO0 / O0oo0OO0
 if 30 - 30: O0oo0OO0
zip = IiiIII111iI . getSetting ( 'zip' )
OOoOooOOOOOo = xbmcgui . Dialog ( )
IiiIII111ii = xbmcgui . DialogProgress ( )
i1iIIi1 = xbmc . translatePath ( os . path . join ( 'special://home/userdata' , '' ) )
ii11iIi1I = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'addon_data' ) )
iI111I11I1I1 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
OOooO0OOoo = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'guisettings.xml' ) )
iIii1 = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'favourites.xml' ) )
oOOoO0 = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'favourites2.xml' ) )
O0OoO000O0OO = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'sources.xml' ) )
iiI1IiI = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'advancedsettings.xml' ) )
IIooOoOoo0O = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'RssFeeds.xml' ) )
OooO0 = xbmc . translatePath ( os . path . join ( i1iIIi1 , 'keymaps' , 'keyboard.xml' ) )
II11iiii1Ii = xbmc . translatePath ( os . path . join ( zip ) )
OO0oOoo = xbmc . getSkinDir ( )
O0o0Oo = xbmc . translatePath ( 'special://home/' )
Oo00OOOOO = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OOOo0 ) )
O0O = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OOOo0 , 'resources' , 'skins' ) )
O00o0OO = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , OOOo0 , 'flag.xml' ) )
I11i1 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , 'skin.infinitytv_demo' , 'addon.xml' ) )
iIi1ii1I1 = xbmc . translatePath ( os . path . join ( 'special://home' , 'media' , 'launch.jpg' ) )
if 71 - 71: oooO0oOOOOo0o . i1
o0OO0oo0oOO = "0.0.11"
oo0oooooO0 = "itv_wizard"
if 19 - 19: OOoO + OoOoo0
if 53 - 53: i1oOo0OoO . iIIIiiIIiiiIi
if 18 - 18: I1i1iI1i
I1i1I1II = OOOo0 ; i1IiIiiI = "Total Wipe"
I1I = [ OOOo0 , 'skin.infinitytv_demo' ]
oOO00oOO = [ OOOo0 , 'addon_data' , 'skin.infinitytv_demo' ]
OoOo = [ "favourites2.xml" , "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , "app.jpg" , "launch.jpg" , "Splash.png" ]
iI = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , "app.jpg" , "launch.jpg" , "Splash.png" ]
if 60 - 60: OOoO / OOoO
def I1II1III11iii ( default = "" , heading = "" , hidden = False ) :
 Oo000 = xbmc . Keyboard ( default , heading , hidden )
 if 51 - 51: i11iIiiIii . iii1I1I + Oo
 Oo000 . doModal ( )
 if ( Oo000 . isConfirmed ( ) ) :
  return unicode ( Oo000 . getText ( ) , "utf-8" )
 return default
 if 10 - 10: II * OoOoo0 * Oo % ooo0Oo0 . ooO + oooO0oOOOOo0o
def IIiIi11i1 ( sourcefile , destfile , message_header , message1 , message2 , message3 , exclude_dirs , exclude_files ) :
 IIIii1II1II = zipfile . ZipFile ( destfile , 'w' , zipfile . ZIP_DEFLATED )
 i1I1iI = len ( sourcefile )
 oo0OooOOo0 = [ ]
 o0OO00oO = [ ]
 IiiIII111ii . create ( message_header , message1 , message2 , message3 )
 for OO0o , I11i1I1I , oO0Oo in os . walk ( sourcefile ) :
  for file in oO0Oo :
   o0OO00oO . append ( file )
 oOOoo0Oo = len ( o0OO00oO )
 for OO0o , I11i1I1I , oO0Oo in os . walk ( sourcefile ) :
  I11i1I1I [ : ] = [ o00OO00OoO for o00OO00OoO in I11i1I1I if o00OO00OoO not in exclude_dirs ]
  oO0Oo [ : ] = [ OOOO0OOoO0O0 for OOOO0OOoO0O0 in oO0Oo if OOOO0OOoO0O0 not in exclude_files ]
  for file in oO0Oo :
   oo0OooOOo0 . append ( file )
   O0Oo000ooO00 = len ( oo0OooOOo0 ) / float ( oOOoo0Oo ) * 100
   IiiIII111ii . update ( int ( O0Oo000ooO00 ) , "Backing up..." , '[COLOR yellow]%s[/COLOR]' % file , 'Please wait' )
   oO0 = os . path . join ( OO0o , file )
   if not 'temp' in I11i1I1I :
    if not OOOo0 in I11i1I1I :
     import time
     Ii1iIiII1ii1 = '01/01/1980'
     ooOooo000oOO = time . strftime ( '%d/%m/%Y' , time . gmtime ( os . path . getmtime ( oO0 ) ) )
     if ooOooo000oOO > Ii1iIiII1ii1 :
      IIIii1II1II . write ( oO0 , oO0 [ i1I1iI : ] )
 IIIii1II1II . close ( )
 IiiIII111ii . close ( )
 if 59 - 59: Oo + i1oOo0OoO * Oo0ooO0oo0oO + iIIIiiIIiiiIi
def Oo0OoO00oOO0o ( name , url , description ) :
 OOO00O = xbmcgui . Dialog ( ) . yesno ( "[COLOR red]VERY IMPORTANT: [/COLOR]" , 'This will completely wipe your infinity tv box settings.' , 'Would you like to create a backup before proceeding?' , '' , yeslabel = 'Yes' , nolabel = 'No' )
 if OOO00O == 1 :
  OOoOO0oo0ooO = urllib . quote_plus ( "backup" )
  O0o0O00Oo0o0 = xbmc . translatePath ( os . path . join ( Oo00OOOOO , OOoOO0oo0ooO + '.zip' ) )
  O00O0oOO00O00 = [ OOOo0 , 'Thumbnails' ]
  iI = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Textures13.db' ]
  i1Oo00 = "Creating backup... "
  i1i = "This will be saved in the[CR]xbmc/addon/plugin.video.itv_wizard folder. "
  iiI111I1iIiI = ""
  IIIi1I1IIii1II = "Please wait"
  IIiIi11i1 ( O0o0Oo , O0o0O00Oo0o0 , i1Oo00 , i1i , iiI111I1iIiI , IIIi1I1IIii1II , O00O0oOO00O00 , iI )
 if 65 - 65: ooo0Oo0 . o0 / i1 - ooo0Oo0
 if 21 - 21: iii1I1I * o0
 if 91 - 91: OOo000
 if 15 - 15: Oo
 if 18 - 18: i11iIiiIii . iIIIiiIIiiiIi % i1oOo0OoO / i1
 if 75 - 75: Oo0ooO0oo0oO % I1i1iI1i % I1i1iI1i . oooO0oOOOOo0o
 III1iII1I1ii = xbmcgui . Dialog ( ) . yesno ( "[COLOR red]FINAL WARNING!!! [/COLOR]" , 'Are you absolutely certain about wiping your infinity tv box settings?' , '' , 'All addons and userdata will be gone!' , yeslabel = 'Yes' , nolabel = 'No' )
 if III1iII1I1ii == 0 :
  return
 elif III1iII1I1ii == 1 :
  oOOo0 = 0
  IiiIII111ii . create ( "[B]itv wizard[/B]" , "Wiping infinity tv Device..." , '' , 'Please wait' )
  try :
   for oo00O00oO , I11i1I1I , oO0Oo in os . walk ( O0o0Oo , topdown = True ) :
    I11i1I1I [ : ] = [ o00OO00OoO for o00OO00OoO in I11i1I1I if o00OO00OoO not in I1I ]
    for name in oO0Oo :
     iIiIIIi = min ( 100 * oOOo0 / name , 100 )
     try :
      os . remove ( os . path . join ( oo00O00oO , name ) )
      os . rmdir ( os . path . join ( oo00O00oO , name ) )
      IiiIII111ii . update ( iIiIIIi )
     except : pass
     if 93 - 93: i1OOooo0000ooo
    for name in I11i1I1I :
     IiiIII111ii . update ( iIiIIIi )
     try : os . rmdir ( os . path . join ( oo00O00oO , name ) ) ; os . rmdir ( oo00O00oO )
     except : pass
  except : pass
 i1IIIiiII1 ( )
 i1IIIiiII1 ( )
 i1IIIiiII1 ( )
 i1IIIiiII1 ( )
 i1IIIiiII1 ( )
 i1IIIiiII1 ( )
 i1IIIiiII1 ( )
 OOoOooOOOOOo . ok ( '[B]itv wizard[/B]' , 'Wipe complete! Please restart infinity tv box for changes to take effect.' , '' , '' )
 return OOOOoOoo0O0O0 ( name , url , description )
 if 85 - 85: i11Ii11I1Ii1i % i11iIiiIii - i1OOooo0000ooo * i1oOo0OoO / iii1I1I % iii1I1I
def i1IIIiiII1 ( ) :
 print "########### Start Removing Empty Folders #########"
 IIiIi1iI = 0
 i1IiiiI1iI = 0
 for i1iIi , ooOOoooooo , oO0Oo in os . walk ( O0o0Oo ) :
  if len ( ooOOoooooo ) == 0 and len ( oO0Oo ) == 0 :
   IIiIi1iI += 1
   os . rmdir ( i1iIi )
   print "successfully removed: " + i1iIi
  elif len ( ooOOoooooo ) > 0 and len ( oO0Oo ) > 0 :
   i1IiiiI1iI += 1
   if 1 - 1: O00oOoOoO0o0O / I1i1iI1i % i1OOooo0000ooo * OOo000 . i11iIiiIii
def III1Iiii1I11 ( ) :
 OOO00O = xbmcgui . Dialog ( ) . yesno ( "[COLOR yellow]itv wizard: [/COLOR]" , 'Would you like to create a backup?.' , 'Backup file will be stored in the plugin.video.itv_wizard folder.' , '' , yeslabel = 'Yes' , nolabel = 'No' )
 if OOO00O == 1 :
  OOoOO0oo0ooO = urllib . quote_plus ( "backup" )
  O0o0O00Oo0o0 = xbmc . translatePath ( os . path . join ( Oo00OOOOO , OOoOO0oo0ooO + '.zip' ) )
  O00O0oOO00O00 = [ OOOo0 , 'Thumbnails' ]
  iI = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Textures13.db' ]
  i1Oo00 = "Creating backup... "
  i1i = "This will be saved in the[CR]xbmc/addon/plugin.video.itv_wizard folder. "
  iiI111I1iIiI = ""
  IIIi1I1IIii1II = "Please wait"
  IIiIi11i1 ( O0o0Oo , O0o0O00Oo0o0 , i1Oo00 , i1i , iiI111I1iIiI , IIIi1I1IIii1II , O00O0oOO00O00 , iI )
  OOoOooOOOOOo . ok ( '[B]itv wizard[/B]' , 'Backup complete!' , '' , '' )
 else :
  return
  if 9 - 9: II / O00oOoOoO0o0O - iii1I1I / i1oOo0OoO / o0 - I1i1iI1i
def o00oooO0Oo ( ) :
 OOO0O = O0 ( O00ooooo00 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 o0O0OOO0Ooo = re . compile ( 'update="(.+?)".+?ull_restore="(.+?)".+?dult_full_restore="(.+?)".+?upport_full_restore="(.+?)".+?upport_update="(.+?)"' ) . findall ( OOO0O )
 for iiIiI , I1 , OOO00O0O , iii , oOooOOOoOo in o0O0OOO0Ooo :
  i1Iii1i1I = iiIiI
  OOoO00 = I1
  IiI111111IIII = OOO00O0O
  i1Ii = iii
  ii111iI1iIi1 = oOooOOOoOo
  if 78 - 78: O0oo0OO0 . ooO + O0oo0OO0 / OOoO / O0oo0OO0
  oO0O00OoOO0 = '[COLOR blue]Name: [/COLOR]Infinity TV'
  OoO = '[COLOR blue]Website: [/COLOR]www.infinitytv.ca'
  O00 = '[COLOR blue]Support: [/COLOR]support@infinitytv.ca / www.itvforum.ca'
  I1iI1 = '[COLOR blue]Last full restore release :[/COLOR] ' + i1Ii
  iiiIi1 = '[COLOR blue]Last update release :[/COLOR] ' + ii111iI1iIi1
  i1I1ii11i1Iii = '[COLOR blue]Facebook:[/COLOR] facebook.com/myinfinitytv'
  OOoOooOOOOOo . ok ( '[B]Infinity tv info[/B]' , OoO , O00 , i1I1ii11i1Iii + '[CR]' + I1iI1 + '[CR]' + iiiIi1 )
  if 26 - 26: OOoO - o0 - iii1I1I / O0oo0OO0 . Oo0ooO0oo0oO % o0
  if 91 - 91: I1i1iI1i . o0 / i11Ii11I1Ii1i + iIIIiiIIiiiIi
  if 42 - 42: OoOoo0 . I1i1iI1i . OoOoo0 - II
i1ii1I1I1 = xbmc . translatePath ( os . path . join ( O0O , 'wipe.png' ) )
oO = xbmc . translatePath ( os . path . join ( O0O , 'support.png' ) )
oO0O0o0Oooo = xbmc . translatePath ( os . path . join ( O0O , 'fanart.jpg' ) )
I1Ii1iI1 = xbmc . translatePath ( os . path . join ( O0O , 'restore.png' ) )
oO0O0OO0O = xbmc . translatePath ( os . path . join ( O0O , 'backup.png' ) )
OO = xbmc . translatePath ( os . path . join ( O0O , 'full_restore.png' ) )
OoOoO = xbmc . translatePath ( os . path . join ( O0O , 'adult_full_restore.png' ) )
Ii1I1i = xbmc . translatePath ( os . path . join ( O0O , 'updates.png' ) )
OOI1iI1ii1II = xbmc . translatePath ( os . path . join ( O0O , 'restore_backup.png' ) )
O0O0OOOOoo = xbmc . translatePath ( os . path . join ( O0O , 'stepone.png' ) )
oOooO0 = xbmc . translatePath ( os . path . join ( O0O , 'steptwo.png' ) )
Ii1I1Ii = xbmc . translatePath ( os . path . join ( O0O , 'stepthree.png' ) )
OOoO0 = xbmc . translatePath ( os . path . join ( O0O , 'fixes.png' ) )
if 86 - 86: i11Ii11I1Ii1i * I1i1iI1i % iIIIiiIIiiiIi . ooo0Oo0 . i11iIiiIii
def oOOoo00O00o ( ) :
 if 98 - 98: ooO + OOo000 + i11Ii11I1Ii1i % i1oOo0OoO
 if 97 - 97: i1 * i1oOo0OoO . i1oOo0OoO
 if 33 - 33: oooO0oOOOOo0o + i1OOooo0000ooo * i11Ii11I1Ii1i / o0 - iii1I1I
 O0oO = '<favourites>\n'
 OOOO0OOoO0O0 = open ( O00o0OO , mode = 'w' )
 OOOO0OOoO0O0 . write ( O0oO )
 OOOO0OOoO0O0 . close ( )
 if 73 - 73: II * i11iIiiIii % i11Ii11I1Ii1i . II
 if not ( os . path . isfile ( iIi1ii1I1 ) ) :
  OOOOo0 = IIi1IiiiI1Ii
  IiiiIIiIi1 = 'media'
  OoOOoOooooOOo = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
  oOo0O = os . path . join ( OoOOoOooooOOo , IiiiIIiIi1 + '.zip' )
  try :
   os . remove ( oOo0O )
  except :
   pass
  downloader . download ( OOOOo0 , oOo0O )
  oo0O0 = xbmc . translatePath ( os . path . join ( 'special://home' , 'media' ) )
  time . sleep ( 2 )
  extract . all ( oOo0O , oo0O0 )
  if 22 - 22: Oo0ooO0oo0oO . ooO * Oo0ooO0oo0oO
  if 54 - 54: OOo000 + ooo0Oo0 % O0oo0OO0 + i1oOo0OoO - i1 - I1i1iI1i
 if not ( os . path . isfile ( I11i1 ) ) :
  OOOOo0 = I11i11Ii
  IiiiIIiIi1 = 'skin.infinitytv_demo'
  OoOOoOooooOOo = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
  IiiIII111ii = xbmcgui . DialogProgress ( )
  IiiIII111ii . create ( "ITV Wizard" , "Quick Update... " , '' , 'Please wait' )
  oOo0O = os . path . join ( OoOOoOooooOOo , IiiiIIiIi1 + '.zip' )
  try :
   os . remove ( oOo0O )
  except :
   pass
  downloader . download ( OOOOo0 , oOo0O , IiiIII111ii )
  oo0O0 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
  time . sleep ( 2 )
  IiiIII111ii . update ( 0 , "" , "Installing..." )
  extract . all ( oOo0O , oo0O0 , IiiIII111ii )
  IiiIII111ii . update ( 0 , "" , "Finishing up..." )
  time . sleep ( 5 )
  try :
   os . remove ( oOo0O )
  except :
   pass
  OOoOooOOOOOo = xbmcgui . Dialog ( )
  OOoOooOOOOOo . ok ( "ITV Wizard" , "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish update. [/COLOR]" )
  if 77 - 77: ooO * o0
  if 98 - 98: iii1I1I % ooo0Oo0 * i1oOo0OoO
  if 51 - 51: o0 . Oo0ooO0oo0oO / i11Ii11I1Ii1i + I1i1iI1i
 OOO0O = O0 ( O00ooooo00 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 o0O0OOO0Ooo = re . compile ( 'update="(.+?)".+?ull_restore="(.+?)".+?dult_full_restore="(.+?)".+?upport_full_restore="(.+?)".+?upport_update="(.+?)"' ) . findall ( OOO0O )
 for iiIiI , I1 , OOO00O0O , iii , oOooOOOoOo in o0O0OOO0Ooo :
  i1Iii1i1I = iiIiI
  OOoO00 = I1
  IiI111111IIII = OOO00O0O
  print i1Iii1i1I
  print OOoO00
  print IiI111111IIII
  print '###############################################################################################################################################'
  I11 ( 'Support Info' , Oo0Ooo , 3 , oO , oO0O0o0Oooo , 'Support info from your TV box seller. ' )
  I11 ( 'Update ' + '[COLOR orange]Latest Update ' + i1Iii1i1I + '[/COLOR]' , Oo0Ooo , 1 , Ii1I1i , oO0O0o0Oooo , 'Update your box' )
  iI1i1I11I11 ( 'Full Restore ' + '[COLOR orange]Latest Build ' + OOoO00 + '[/COLOR]' , O0O0OO0O0O0 , 9 , OO , oO0O0o0Oooo , 'All addons and userdata will be completely wiped!' )
  iI1i1I11I11 ( 'Adult Full Restore ' + '[COLOR orange]Latest Build ' + IiI111111IIII + '[/COLOR]' , iiiii , 10 , OoOoO , oO0O0o0Oooo , 'All addons and userdata will be completely wiped!' )
  if 69 - 69: Oo0ooO0oo0oO
  if 97 - 97: II % II % i11Ii11I1Ii1i / i1OOooo0000ooo - o0
  if 69 - 69: oooO0oOOOOo0o
  ii1I1 ( 'movies' , 'MAIN' )
  if 93 - 93: i1 % iIIIiiIIiiiIi . ooO / iii1I1I - oooO0oOOOOo0o / iii1I1I
def II1IiiIi1i ( name , url , description ) :
 url = oO00oOo
 name = 'skin.infinitytv'
 OoOOoOooooOOo = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
 IiiIII111ii = xbmcgui . DialogProgress ( )
 IiiIII111ii . create ( "ITV Wizard" , "Fixing skin issues... " , '' , 'Please wait' )
 oOo0O = os . path . join ( OoOOoOooooOOo , name + '.zip' )
 try :
  os . remove ( oOo0O )
 except :
  pass
 downloader . download ( url , oOo0O , IiiIII111ii )
 oo0O0 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
 time . sleep ( 2 )
 IiiIII111ii . update ( 0 , "" , "Installing..." )
 extract . all ( oOo0O , oo0O0 , IiiIII111ii )
 IiiIII111ii . update ( 0 , "" , "Finishing up..." )
 time . sleep ( 5 )
 OOoOooOOOOOo = xbmcgui . Dialog ( )
 OOoOooOOOOOo . ok ( "ITV Wizard" , "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish update. [/COLOR]" )
 if 29 - 29: iii1I1I % iii1I1I
def Oo0O0 ( name , url , description ) :
 OOoOooOOOOOo = xbmcgui . Dialog ( )
 OOoOooOOOOOo . ok ( "ITV Wizard" , "[COLOR blue]Please press YES on the next popup. [/COLOR]" , "" , "Then move to STEP TWO!" )
 Ooo0OOoOoO0 ( 'lookandfeel.skin' , 'skin.infinitytv_demo' )
 if 70 - 70: i11Ii11I1Ii1i
def oOOoO0o0oO ( name , url , description ) :
 I11 ( 'STEP ONE' , oO00oOo , 12 , O0O0OOOOoo , oO0O0o0Oooo , 'All addons and userdata will be completely wiped!' )
 I11 ( 'STEP TWO' , oO00oOo , 13 , oOooO0 , oO0O0o0Oooo , 'All addons and userdata will be completely wiped!' )
 ii1I1 ( 'movies' , 'MAIN' )
 if 93 - 93: OOo000 * i1oOo0OoO + OoOoo0
 if 33 - 33: i1 * I1i1iI1i - oooO0oOOOOo0o % oooO0oOOOOo0o
def I11I ( name , url , description ) :
 I11iIi1i1II11 = 'lookandfeel.skin'
 OO0oOoo = iiI ( I11iIi1i1II11 )
 if 26 - 26: ooo0Oo0 % II
 if ( os . path . isfile ( O00o0OO ) ) :
  OOoOooOOOOOo = xbmcgui . Dialog ( )
  OOoOooOOOOOo . ok ( "ITV Wizard" , "[COLOR blue]Please press Ok and then Click on Step 1, and follow the next prompts![/COLOR]" )
  if 76 - 76: OOo000 * i1OOooo0000ooo
 I11 ( 'STEP ONE' , O0O0OO0O0O0 , 7 , O0O0OOOOoo , oO0O0o0Oooo , 'All addons and userdata will be completely wiped!' )
 I11 ( 'STEP TWO' , O0O0OO0O0O0 , 6 , oOooO0 , oO0O0o0Oooo , 'All addons and userdata will be completely wiped!' )
 I11 ( 'STEP THREE' , O0O0OO0O0O0 , 8 , Ii1I1Ii , oO0O0o0Oooo , 'All addons and userdata will be completely wiped!' )
 ii1I1 ( 'movies' , 'MAIN' )
 if 52 - 52: ooO
def iiii1 ( name , url , description ) :
 if ( os . path . isfile ( O00o0OO ) ) :
  OOoOooOOOOOo = xbmcgui . Dialog ( )
  OOoOooOOOOOo . ok ( "ITV Wizard" , "[COLOR blue]Please press Ok and then Click on Step 1, and follow the next prompts![/COLOR]" )
  if 96 - 96: i11iIiiIii % ooO
 I11 ( 'STEP ONE' , iiiii , 7 , O0O0OOOOoo , oO0O0o0Oooo , 'All addons and userdata will be completely wiped!' )
 I11 ( 'STEP TWO' , iiiii , 6 , oOooO0 , oO0O0o0Oooo , 'All addons and userdata will be completely wiped!' )
 I11 ( 'STEP THREE' , iiiii , 8 , Ii1I1Ii , oO0O0o0Oooo , 'All addons and userdata will be completely wiped!' )
 ii1I1 ( 'movies' , 'MAIN' )
 if 70 - 70: o0
def i11ii1iI ( ) :
 try :
  os . remove ( O00o0OO )
 except :
  pass
 OOoOooOOOOOo = xbmcgui . Dialog ( )
 OOoOooOOOOOo . ok ( "ITV Wizard" , "[COLOR blue]Please press YES on the next popup. [/COLOR]" , "" , "Then move to STEP TWO!" )
 Ooo0OOoOoO0 ( 'lookandfeel.skin' , 'skin.infinitytv_demo' )
 if 22 - 22: i1oOo0OoO
def OOOOOo ( ) :
 xbmc . executebuiltin ( 'ReloadSkin()' )
 if 25 - 25: i1 * OOoO + II . I1i1iI1i . I1i1iI1i
 if 58 - 58: iii1I1I
def Ooo0OOoOoO0 ( setting , value ) :
 setting = '"%s"' % setting
 if 53 - 53: iIIIiiIIiiiIi
 if isinstance ( value , list ) :
  o0OOOoO0 = ''
  for o0OoOo00o0o in value :
   o0OOOoO0 += '"%s",' % str ( o0OoOo00o0o )
   if 41 - 41: OoOoo0 % O0oo0OO0 - O00oOoOoO0o0O * oooO0oOOOOo0o * O00oOoOoO0o0O
  o0OOOoO0 = o0OOOoO0 [ : - 1 ]
  o0OOOoO0 = '[%s]' % o0OOOoO0
  value = o0OOOoO0
  if 69 - 69: ooO - i1oOo0OoO + I1i1iI1i - OOoO
 elif not isinstance ( value , int ) :
  value = '"%s"' % value
  if 23 - 23: i11iIiiIii
 II1iIi11 = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}' % ( setting , value )
 xbmc . executeJSONRPC ( II1iIi11 )
 if 12 - 12: ooo0Oo0 + i11iIiiIii * o0 / II . OOoO
def iiI ( setting ) :
 if 5 - 5: iIIIiiIIiiiIi + OOo000 / I1i1iI1i . i1OOooo0000ooo / OOoO
 import json
 setting = '"%s"' % setting
 if 32 - 32: iii1I1I % o0 / iIIIiiIIiiiIi - iii1I1I
 II1iIi11 = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}' % ( setting )
 Iiii = xbmc . executeJSONRPC ( II1iIi11 )
 if 7 - 7: oooO0oOOOOo0o * O0oo0OO0 - OoOoo0 + ooO * iii1I1I % O0oo0OO0
 Iiii = json . loads ( Iiii )
 if 15 - 15: Oo0ooO0oo0oO % iii1I1I * OOoO
 if Iiii . has_key ( 'result' ) :
  if Iiii [ 'result' ] . has_key ( 'value' ) :
   return Iiii [ 'result' ] [ 'value' ]
   if 81 - 81: OoOoo0 - o0 - iIIIiiIIiiiIi / oooO0oOOOOo0o - i1 * OOoO
   if 20 - 20: i11Ii11I1Ii1i % OOo000
def OOOOoOoo0O0O0 ( name , url , description ) :
 if 19 - 19: II % OOo000 + OoOoo0 / oooO0oOOOOo0o . OoOoo0
 OoOOoOooooOOo = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
 IiiIII111ii = xbmcgui . DialogProgress ( )
 IiiIII111ii . create ( "ITV Wizard" , "Downloading... " , '' , 'Please wait' )
 oOo0O = os . path . join ( OoOOoOooooOOo , name + '.zip' )
 try :
  os . remove ( oOo0O )
 except :
  pass
 downloader . download ( url , oOo0O , IiiIII111ii )
 oo0O0 = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
 if 12 - 12: iIIIiiIIiiiIi + iIIIiiIIiiiIi - II * O00oOoOoO0o0O % O00oOoOoO0o0O - Oo
 time . sleep ( 2 )
 IiiIII111ii . update ( 0 , "" , "Installing..." )
 extract . all ( oOo0O , oo0O0 , IiiIII111ii )
 IiiIII111ii . update ( 0 , "" , "Finishing up..." )
 time . sleep ( 5 )
 if 52 - 52: OoOoo0 . i1OOooo0000ooo + oooO0oOOOOo0o
 if 38 - 38: iIIIiiIIiiiIi - Oo . oooO0oOOOOo0o
 if 58 - 58: iii1I1I . i1OOooo0000ooo + Oo0ooO0oo0oO
 if 66 - 66: i1OOooo0000ooo / i11Ii11I1Ii1i * i1oOo0OoO + i1oOo0OoO % OOoO
 OOoOooOOOOOo = xbmcgui . Dialog ( )
 OOoOooOOOOOo . ok ( "ITV Wizard" , "[COLOR blue]Installation nearly complete but one important step remains. [/COLOR]" )
 OOoOooOOOOOo = xbmcgui . Dialog ( )
 OOoOooOOOOOo . ok ( "ITV Wizard" , "[COLOR red]URGENT: Please power off your device immediately and then reboot to finish setup. [/COLOR]" )
 if 49 - 49: i11Ii11I1Ii1i - i11iIiiIii . oooO0oOOOOo0o * ooo0Oo0 % i1OOooo0000ooo + iIIIiiIIiiiIi
def oOO0OOOo ( ) :
 try :
  os . remove ( O00o0OO )
 except :
  pass
  if 56 - 56: I1i1iI1i
  if 28 - 28: i1OOooo0000ooo . i1OOooo0000ooo % o0 * o0 . I1i1iI1i / i1OOooo0000ooo
def iII1i1 ( name , url , description ) :
 IiiIII111ii = xbmcgui . DialogProgress ( )
 III1iII1I1ii = xbmcgui . Dialog ( ) . yesno ( "[COLOR red]WARNING!!! [/COLOR]" , 'By pressing [COLOR green]YES[/COLOR] you will restore ' , 'your Infinity TV to the latest complete build.' , '' , yeslabel = 'YES' , nolabel = 'NO' )
 if III1iII1I1ii == 0 :
  Ooo0OOoOoO0 ( 'lookandfeel.skin' , 'skin.infinitytv' )
  return
 elif III1iII1I1ii == 1 :
  O0oOOoooOO0O = xbmcgui . Dialog ( ) . yesno ( "[COLOR yellow]Would you like to Save your Favorites? [/COLOR]" , '-By pressing [COLOR green]YES[/COLOR] all your Favorites will be [COLOR green]saved[/COLOR]. ' , '-If you press [COLOR red]NO[/COLOR] your Favorites will be [COLOR red]wiped[/COLOR]' , '-Both options will restore your Infinity TV to the Latest Software Build.' , yeslabel = 'YES' , nolabel = 'NO' )
  if 86 - 86: I1i1iI1i
  if O0oOOoooOO0O == 0 :
   IiiIII111ii . create ( "[B]itv wizard[/B]" , "Wiping infinity tv device..." , '' , 'Please wait as it will take a few minutes' )
   try :
    for oo00O00oO , I11i1I1I , oO0Oo in os . walk ( O0o0Oo , topdown = True ) :
     I11i1I1I [ : ] = [ o00OO00OoO for o00OO00OoO in I11i1I1I if o00OO00OoO not in I1I ]
     oO0Oo [ : ] = [ OOOO0OOoO0O0 for OOOO0OOoO0O0 in oO0Oo if OOOO0OOoO0O0 not in iI ]
     for name in oO0Oo :
      try :
       os . remove ( os . path . join ( oo00O00oO , name ) )
       os . rmdir ( os . path . join ( oo00O00oO , name ) )
      except : pass
      if 5 - 5: OOo000 * Oo0ooO0oo0oO
     for name in I11i1I1I :
      try : os . rmdir ( os . path . join ( oo00O00oO , name ) ) ; os . rmdir ( oo00O00oO )
      except : pass
   except : pass
   if 5 - 5: oooO0oOOOOo0o
   i1IIIiiII1 ( )
   i1IIIiiII1 ( )
   i1IIIiiII1 ( )
   i1IIIiiII1 ( )
   i1IIIiiII1 ( )
   i1IIIiiII1 ( )
   i1IIIiiII1 ( )
   if 90 - 90: oooO0oOOOOo0o . OoOoo0 / ooo0Oo0 - OOoO
   if 40 - 40: i1oOo0OoO
   time . sleep ( 2 )
   OoOOoOooooOOo = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
   IiiIII111ii = xbmcgui . DialogProgress ( )
   IiiIII111ii . create ( "ITV Wizard" , "Wipe complete! Now Downloading... " , '' , 'Please wait' )
   if 25 - 25: OOo000 + ooo0Oo0 / OoOoo0 . I1i1iI1i % i1 * O0oo0OO0
   oOo0O = os . path . join ( OoOOoOooooOOo , 'fullbackup.zip' )
   try :
    os . remove ( oOo0O )
   except :
    pass
   downloader . download ( url , oOo0O , IiiIII111ii )
   oo0O0 = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
   time . sleep ( 2 )
   IiiIII111ii . update ( 0 , "" , "Installing..." )
   extract . all ( oOo0O , oo0O0 , IiiIII111ii )
   IiiIII111ii . update ( 0 , "" , "Finishing up..." )
   time . sleep ( 3 )
   xbmc . executebuiltin ( 'UpdateLocalAddons' )
   xbmc . executebuiltin ( "UpdateAddonRepos" )
   time . sleep ( 2 )
   OOoOooOOOOOo = xbmcgui . Dialog ( )
   OOoOooOOOOOo . ok ( "ITV Wizard" , "[COLOR blue]Please press YES on next popup! [/COLOR]" , "" , "Then Click on STEP THREE!" )
   Ooo0OOoOoO0 ( 'lookandfeel.skin' , 'skin.infinitytv' )
   if 84 - 84: OoOoo0 % ooo0Oo0 + i11iIiiIii
   if 28 - 28: O00oOoOoO0o0O + O0oo0OO0 * ooO % i11Ii11I1Ii1i . OOoO % i1
   if 16 - 16: OOoO - o0 / iii1I1I . Oo + o0
   if 19 - 19: O0oo0OO0 - O00oOoOoO0o0O . i1
   if 60 - 60: Oo + O00oOoOoO0o0O
   if 9 - 9: OoOoo0 * i1oOo0OoO - o0 + Oo0ooO0oo0oO / O0oo0OO0 . O0oo0OO0
   if 49 - 49: Oo
   if 25 - 25: i1oOo0OoO - iii1I1I . iii1I1I * i11Ii11I1Ii1i
  elif O0oOOoooOO0O == 1 :
   if 81 - 81: i1OOooo0000ooo + OOo000
   if 98 - 98: iii1I1I
   o00o0 = open ( iIii1 ) . read ( )
   OOOO0OOoO0O0 = open ( oOOoO0 , mode = 'w' )
   OOOO0OOoO0O0 . write ( o00o0 )
   OOOO0OOoO0O0 . close ( )
   if 50 - 50: O00oOoOoO0o0O / O00oOoOoO0o0O % II . II
   if 55 - 55: OoOoo0 - OOoO + Oo + i1OOooo0000ooo % ooo0Oo0
   IiiIII111ii . create ( "[B]itv wizard[/B]" , "Wiping infinity tv device..." , '' , 'Please wait as it will take a few minutes' )
   try :
    for oo00O00oO , I11i1I1I , oO0Oo in os . walk ( O0o0Oo , topdown = True ) :
     I11i1I1I [ : ] = [ o00OO00OoO for o00OO00OoO in I11i1I1I if o00OO00OoO not in oOO00oOO ]
     oO0Oo [ : ] = [ OOOO0OOoO0O0 for OOOO0OOoO0O0 in oO0Oo if OOOO0OOoO0O0 not in OoOo ]
     for name in oO0Oo :
      try :
       os . remove ( os . path . join ( oo00O00oO , name ) )
       os . rmdir ( os . path . join ( oo00O00oO , name ) )
      except : pass
      if 41 - 41: iIIIiiIIiiiIi - OOoO - ooo0Oo0
     for name in I11i1I1I :
      try : os . rmdir ( os . path . join ( oo00O00oO , name ) ) ; os . rmdir ( oo00O00oO )
      except : pass
   except : pass
   if 8 - 8: O0oo0OO0 + oooO0oOOOOo0o - I1i1iI1i % O00oOoOoO0o0O % I1i1iI1i * i11Ii11I1Ii1i
   i1IIIiiII1 ( )
   i1IIIiiII1 ( )
   i1IIIiiII1 ( )
   i1IIIiiII1 ( )
   i1IIIiiII1 ( )
   i1IIIiiII1 ( )
   i1IIIiiII1 ( )
   if 9 - 9: O00oOoOoO0o0O - i11iIiiIii - ooO * ooo0Oo0 + OoOoo0
   if 44 - 44: Oo
   time . sleep ( 2 )
   OoOOoOooooOOo = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
   IiiIII111ii = xbmcgui . DialogProgress ( )
   IiiIII111ii . create ( "ITV Wizard" , "Wipe complete! Now Downloading... " , '' , 'Please wait' )
   if 52 - 52: II - O00oOoOoO0o0O + II % I1i1iI1i
   if 35 - 35: o0
   I1i ( )
   iIII ( )
   if 70 - 70: i1OOooo0000ooo / o0
   if 85 - 85: i1oOo0OoO % iIIIiiIIiiiIi * i1oOo0OoO / II
   oOo0O = os . path . join ( OoOOoOooooOOo , 'fullbackup.zip' )
   try :
    os . remove ( oOo0O )
   except :
    pass
   if 'adult' in url :
    url = ooo0OO
    downloader . download ( url , oOo0O , IiiIII111ii )
    oo0O0 = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
    time . sleep ( 2 )
    IiiIII111ii . update ( 0 , "" , "Installing..." )
    extract . all ( oOo0O , oo0O0 , IiiIII111ii )
    IiiIII111ii . update ( 0 , "" , "Finishing up..." )
    time . sleep ( 3 )
    xbmc . executebuiltin ( 'UpdateLocalAddons' )
    xbmc . executebuiltin ( "UpdateAddonRepos" )
    time . sleep ( 2 )
    OOoOooOOOOOo = xbmcgui . Dialog ( )
    OOoOooOOOOOo . ok ( "ITV Wizard" , "[COLOR blue]Please press YES on next popup! [/COLOR]" , "" , "Then Click on STEP THREE!" )
    try :
     os . remove ( oOOoO0 )
    except :
     pass
    Ooo0OOoOoO0 ( 'lookandfeel.skin' , 'skin.infinitytv' )
    if 96 - 96: i1oOo0OoO + i11Ii11I1Ii1i
    if 44 - 44: i11Ii11I1Ii1i
    if 20 - 20: OOoO + ooo0Oo0 / i1 % o0
   else :
    url = II1
    downloader . download ( url , oOo0O , IiiIII111ii )
    oo0O0 = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
    time . sleep ( 2 )
    IiiIII111ii . update ( 0 , "" , "Installing..." )
    extract . all ( oOo0O , oo0O0 , IiiIII111ii )
    IiiIII111ii . update ( 0 , "" , "Finishing up..." )
    time . sleep ( 3 )
    xbmc . executebuiltin ( 'UpdateLocalAddons' )
    xbmc . executebuiltin ( "UpdateAddonRepos" )
    time . sleep ( 2 )
    OOoOooOOOOOo = xbmcgui . Dialog ( )
    OOoOooOOOOOo . ok ( "ITV Wizard" , "[COLOR blue]Please press YES on next popup! [/COLOR]" , "" , "Then Click on STEP THREE!" )
    try :
     os . remove ( oOOoO0 )
    except :
     pass
    Ooo0OOoOoO0 ( 'lookandfeel.skin' , 'skin.infinitytv' )
    if 88 - 88: Oo0ooO0oo0oO / Oo
    if 87 - 87: II - II - i1OOooo0000ooo + i11Ii11I1Ii1i
    if 82 - 82: i11Ii11I1Ii1i / o0 . iii1I1I . ooO / I1i1iI1i
    if 42 - 42: O00oOoOoO0o0O
def I1i ( ) :
 from t0mm0 . common . net import Net
 import socket
 import time
 if 19 - 19: i11Ii11I1Ii1i % II * o0 + iii1I1I
 iii11I = Net ( )
 if 50 - 50: i1OOooo0000ooo + i1 + ooo0Oo0 . Oo / I1i1iI1i
 O0oO = '<favourites>\n'
 OOOO0OOoO0O0 = open ( iIii1 , mode = 'w' )
 OOOO0OOoO0O0 . write ( O0oO )
 OOOO0OOoO0O0 . close ( )
 if 17 - 17: ooo0Oo0 % o0 - o0
 O0o0O0 = iii11I . http_GET ( I1IiiI ) . content
 if 11 - 11: Oo % O0oo0OO0 * i1OOooo0000ooo + OoOoo0 + ooo0Oo0
 for o0OoOo00o0o in re . finditer ( r'<favourite name="(.+?)" thumb="(.+?)</favourite>' , O0o0O0 , re . I ) :
  if 24 - 24: O00oOoOoO0o0O - i11Ii11I1Ii1i % o0 . iIIIiiIIiiiIi / i1
  IiiiIIiIi1 = o0OoOo00o0o . group ( 1 )
  ii1ii111 = o0OoOo00o0o . group ( 2 )
  if 10 - 10: oooO0oOOOOo0o % OOo000 * OOo000 . OOoO / ooo0Oo0 % ooO
  if 49 - 49: O0oo0OO0 / i11Ii11I1Ii1i + i1 * I1i1iI1i
  try :
   O0oO = '    <favourite name="%s" thumb="%s</favourite>\n' % ( IiiiIIiIi1 , ii1ii111 )
   if 28 - 28: OoOoo0 + i11iIiiIii / OOoO % Oo0ooO0oo0oO % O00oOoOoO0o0O - i1
   OOOO0OOoO0O0 = open ( iIii1 , mode = 'a' )
   OOOO0OOoO0O0 . write ( O0oO )
   OOOO0OOoO0O0 . close ( )
  except :
   continue
 if 54 - 54: iIIIiiIIiiiIi + Oo
 if 83 - 83: II - iii1I1I + ooO
 if 5 - 5: ooo0Oo0
 if 46 - 46: OOo000
 if 45 - 45: OoOoo0
 if 21 - 21: i11Ii11I1Ii1i . oooO0oOOOOo0o . ooO / O00oOoOoO0o0O / oooO0oOOOOo0o
def iIII ( ) :
 from t0mm0 . common . net import Net
 import socket
 import time
 if 17 - 17: ooO / ooO / OOoO
 iii11I = Net ( )
 if 1 - 1: iIIIiiIIiiiIi . i11iIiiIii % ooO
 if 82 - 82: o0 + O00oOoOoO0o0O . o0 % OOo000 / ooo0Oo0 . ooo0Oo0
 if 14 - 14: I1i1iI1i . ooO . OOoO + i1oOo0OoO - ooO + OOo000
 if 9 - 9: ooo0Oo0
 if 59 - 59: iii1I1I * Oo . i1
 if 56 - 56: ooo0Oo0 - i1OOooo0000ooo % iii1I1I - I1i1iI1i
 o00o0 = open ( oOOoO0 ) . read ( )
 Oo00O = '<favourite name="(.+?)" thumb="(.+?)</favourite>'
 o0O0OOO0Ooo = re . compile ( Oo00O ) . findall ( o00o0 )
 print o0O0OOO0Ooo
 for IiiiIIiIi1 , ii1ii111 in o0O0OOO0Ooo :
  if 12 - 12: I1i1iI1i - OoOoo0 * oooO0oOOOOo0o
  II1111ii = open ( iIii1 ) . read ( )
  i1OO0oOOoo = '<favourite name="(.+?)" thumb="(.+?)</favourite>'
  oOOO00o000o = re . compile ( i1OO0oOOoo ) . findall ( II1111ii )
  for iIi11i1 , oO00oo0o00o0o in oOOO00o000o :
   if IiiiIIiIi1 or ii1ii111 in iIi11i1 and oO00oo0o00o0o :
    IiiiIIiIi1 . replace ( iIi11i1 , '' )
    ii1ii111 . replace ( iIi11i1 , '' )
    if 7 - 7: i1 - O00oOoOoO0o0O + II + Oo + o0
   try :
    O0oO = '    <favourite name="%s" thumb="%s</favourite>\n' % ( IiiiIIiIi1 , ii1ii111 )
    if 58 - 58: I1i1iI1i / OOo000 . Oo0ooO0oo0oO / i1oOo0OoO + oooO0oOOOOo0o
    OOOO0OOoO0O0 = open ( iIii1 , mode = 'a' )
    OOOO0OOoO0O0 . write ( O0oO )
    OOOO0OOoO0O0 . close ( )
   except :
    continue
    if 86 - 86: OOoO * iii1I1I + OOoO + Oo
 O0oO = '</favourites>'
 OOOO0OOoO0O0 = open ( iIii1 , mode = 'a' )
 OOOO0OOoO0O0 . write ( O0oO )
 OOOO0OOoO0O0 . close ( )
 if 8 - 8: oooO0oOOOOo0o - i1OOooo0000ooo / OoOoo0
 if 96 - 96: Oo0ooO0oo0oO
def IIiiI ( ) :
 if 31 - 31: II + ooo0Oo0 + oooO0oOOOOo0o / ooo0Oo0
 import time
 if 25 - 25: O0oo0OO0
 try :
  IiiIII111ii = xbmcgui . DialogProgress ( )
  IiiIII111ii . create ( "ITV Wizard" , "Retrieving backup file... " , '' , 'Please wait' )
  oOo0O = xbmc . translatePath ( os . path . join ( Oo00OOOOO , 'backup.zip' ) )
  oo0O0 = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
  time . sleep ( 2 )
  IiiIII111ii . update ( 0 , "" , "Installing..." )
  extract . all ( oOo0O , oo0O0 , IiiIII111ii )
  IiiIII111ii . update ( 0 , "" , "Finishing up..." )
  time . sleep ( 5 )
  OOoOooOOOOOo = xbmcgui . Dialog ( )
  OOoOooOOOOOo . ok ( "ITV Wizard" , "[COLOR yellow]Installation nearly complete but one important step remains. [/COLOR]" )
  OOoOooOOOOOo = xbmcgui . Dialog ( )
  OOoOooOOOOOo . ok ( "ITV Wizard" , "[COLOR red]URGENT: Please unplug or power off your device immediately and then reboot to finish setup. [/COLOR]" )
  if 24 - 24: OOo000 * i11iIiiIii * ooO
 except :
  OOoOooOOOOOo = xbmcgui . Dialog ( )
  OOoOooOOOOOo . ok ( 'ITV Wizard' , 'You need to backup your build first.\nTo backup your box press backup on main menu.' , '' , '' )
  if 85 - 85: I1i1iI1i . Oo0ooO0oo0oO / OoOoo0 . i1 % oooO0oOOOOo0o
  if 90 - 90: O00oOoOoO0o0O % i1 * o0 . i1OOooo0000ooo
  if 8 - 8: OoOoo0 + Oo / i1OOooo0000ooo / OOoO
def I11 ( name , url , mode , iconimage , fanart , description ) :
 ooo0O = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 iII1iii = True
 i11i1iiiII = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i11i1iiiII . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 i11i1iiiII . setProperty ( "Fanart_Image" , fanart )
 iII1iii = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = ooo0O , listitem = i11i1iiiII , isFolder = False )
 return iII1iii
 if 68 - 68: i11iIiiIii * O0oo0OO0
def iI1i1I11I11 ( name , url , mode , iconimage , fanart , description ) :
 ooo0O = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 iII1iii = True
 i11i1iiiII = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i11i1iiiII . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 i11i1iiiII . setProperty ( "Fanart_Image" , fanart )
 iII1iii = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = ooo0O , listitem = i11i1iiiII , isFolder = True )
 return iII1iii
 if 46 - 46: Oo0ooO0oo0oO / o0 % i1OOooo0000ooo . o0 * i1OOooo0000ooo
 if 38 - 38: II - i1OOooo0000ooo / i1 . oooO0oOOOOo0o
 if 45 - 45: oooO0oOOOOo0o
def oOIIi1iiii1iI ( ) :
 iIiiii = [ ]
 O0000OOO0 = sys . argv [ 2 ]
 if len ( O0000OOO0 ) >= 2 :
  ooo0 = sys . argv [ 2 ]
  oO000oOo00o0o = ooo0 . replace ( '?' , '' )
  if ( ooo0 [ len ( ooo0 ) - 1 ] == '/' ) :
   ooo0 = ooo0 [ 0 : len ( ooo0 ) - 2 ]
  O00oO0 = oO000oOo00o0o . split ( '&' )
  iIiiii = { }
  for O0Oo00OoOo in range ( len ( O00oO0 ) ) :
   ii1ii111i11111I1I = { }
   ii1ii111i11111I1I = O00oO0 [ O0Oo00OoOo ] . split ( '=' )
   if ( len ( ii1ii111i11111I1I ) ) == 2 :
    iIiiii [ ii1ii111i11111I1I [ 0 ] ] = ii1ii111i11111I1I [ 1 ]
    if 11 - 11: i1oOo0OoO . oooO0oOOOOo0o
 return iIiiii
 if 80 - 80: i1oOo0OoO - ooO * ooo0Oo0 * II / iii1I1I / ooO
 if 13 - 13: oooO0oOOOOo0o * OoOoo0 + i11iIiiIii * oooO0oOOOOo0o - OoOoo0
ooo0 = oOIIi1iiii1iI ( )
OOOOo0 = None
IiiiIIiIi1 = None
Ii1i1i1i1I1Ii = None
iiiI1 = None
OOOoO0O = None
o0iiiI1I1iIIIi1 = None
if 17 - 17: o0 . i1oOo0OoO / OOoO % Oo % iIIIiiIIiiiIi / i11iIiiIii
if 58 - 58: O00oOoOoO0o0O . Oo + i11Ii11I1Ii1i - i11iIiiIii / Oo / i1
try :
 OOOOo0 = urllib . unquote_plus ( ooo0 [ "url" ] )
except :
 pass
try :
 IiiiIIiIi1 = urllib . unquote_plus ( ooo0 [ "name" ] )
except :
 pass
try :
 iiiI1 = urllib . unquote_plus ( ooo0 [ "iconimage" ] )
except :
 pass
try :
 Ii1i1i1i1I1Ii = int ( ooo0 [ "mode" ] )
except :
 pass
try :
 OOOoO0O = urllib . unquote_plus ( ooo0 [ "fanart" ] )
except :
 pass
try :
 o0iiiI1I1iIIIi1 = urllib . unquote_plus ( ooo0 [ "description" ] )
except :
 pass
 if 85 - 85: Oo0ooO0oo0oO + ooO
 if 10 - 10: OOo000 / O0oo0OO0 + Oo0ooO0oo0oO / iIIIiiIIiiiIi
print str ( oo0oooooO0 ) + ': ' + str ( o0OO0oo0oOO )
print "Mode: " + str ( Ii1i1i1i1I1Ii )
print "URL: " + str ( OOOOo0 )
print "Name: " + str ( IiiiIIiIi1 )
print "IconImage: " + str ( iiiI1 )
if 27 - 27: ooo0Oo0
if 67 - 67: iii1I1I
def ii1I1 ( content , viewType ) :
 if 55 - 55: II - i1OOooo0000ooo * I1i1iI1i + Oo0ooO0oo0oO * Oo0ooO0oo0oO * i1
 if content :
  xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , content )
 if IiiIII111iI . getSetting ( 'auto-view' ) == 'true' :
  xbmc . executebuiltin ( "Container.SetViewMode(%s)" % IiiIII111iI . getSetting ( viewType ) )
  if 91 - 91: oooO0oOOOOo0o - ooO % o0 - i1oOo0OoO % OoOoo0
  if 98 - 98: O0oo0OO0 . O0oo0OO0 * i11Ii11I1Ii1i * Oo * oooO0oOOOOo0o
if Ii1i1i1i1I1Ii == None or OOOOo0 == None or len ( OOOOo0 ) < 1 :
 oOOoo00O00o ( )
 if 92 - 92: O00oOoOoO0o0O
elif Ii1i1i1i1I1Ii == 1 :
 OOOOoOoo0O0O0 ( IiiiIIiIi1 , OOOOo0 , o0iiiI1I1iIIIi1 )
 if 40 - 40: Oo0ooO0oo0oO / OOo000
elif Ii1i1i1i1I1Ii == 2 :
 Oo0OoO00oOO0o ( IiiiIIiIi1 , OOOOo0 , o0iiiI1I1iIIIi1 )
 if 79 - 79: O0oo0OO0 - o0 + ooo0Oo0 - oooO0oOOOOo0o
elif Ii1i1i1i1I1Ii == 3 :
 o00oooO0Oo ( )
 if 93 - 93: Oo . iii1I1I - O00oOoOoO0o0O + Oo0ooO0oo0oO
elif Ii1i1i1i1I1Ii == 4 :
 IIiiI ( )
 if 61 - 61: Oo
elif Ii1i1i1i1I1Ii == 5 :
 III1Iiii1I11 ( )
 if 15 - 15: i11iIiiIii % iii1I1I * OOoO / oooO0oOOOOo0o
elif Ii1i1i1i1I1Ii == 6 :
 iII1i1 ( IiiiIIiIi1 , OOOOo0 , o0iiiI1I1iIIIi1 )
 if 90 - 90: i1OOooo0000ooo
elif Ii1i1i1i1I1Ii == 7 :
 i11ii1iI ( )
 if 31 - 31: ooO + i1
elif Ii1i1i1i1I1Ii == 8 :
 OOoOooOOOOOo = xbmcgui . Dialog ( )
 OOoOooOOOOOo . ok ( "ITV Wizard" , "[COLOR yellow]Last Step![/COLOR]" , "" , "Please press OK for all the changes to take place." )
 OoOOoOooooOOo = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OOOo0 ) )
 oOo0O = os . path . join ( OoOOoOooooOOo , 'fullbackup.zip' )
 import zipfile
 if 87 - 87: OoOoo0
 IIIii = zipfile . ZipFile ( oOo0O , "r" )
 for O00OooOo00o in IIIii . namelist ( ) :
  if 'guisettings.xml' in O00OooOo00o :
   o00o0 = IIIii . read ( O00OooOo00o )
   Oo00O = '<setting type="(.+?)" name="%s.(.+?)">(.+?)</setting>' % OO0oOoo
   if 20 - 20: iIIIiiIIiiiIi * oooO0oOOOOo0o + Oo % I1i1iI1i % i11Ii11I1Ii1i
   o0O0OOO0Ooo = re . compile ( Oo00O ) . findall ( o00o0 )
   print o0O0OOO0Ooo
   for type , iIi1II , I11iIi1i1II11 in o0O0OOO0Ooo :
    I11iIi1i1II11 = I11iIi1i1II11 . replace ( '&quot;' , '' ) . replace ( '&amp;' , '&' )
    xbmc . executebuiltin ( "Skin.Set%s(%s,%s)" % ( type . title ( ) , iIi1II , I11iIi1i1II11 ) )
 try :
  os . remove ( oOo0O )
 except :
  pass
 xbmc . executebuiltin ( "XBMC.ActivateWindow(Home)" )
 xbmc . executebuiltin ( 'ReloadSkin()' )
 if 17 - 17: ooO % O00oOoOoO0o0O / II . OOo000 * ooO - Oo
elif Ii1i1i1i1I1Ii == 9 :
 I11I ( IiiiIIiIi1 , OOOOo0 , o0iiiI1I1iIIIi1 )
 if 41 - 41: ooo0Oo0
elif Ii1i1i1i1I1Ii == 10 :
 iiii1 ( IiiiIIiIi1 , OOOOo0 , o0iiiI1I1iIIIi1 )
 if 77 - 77: oooO0oOOOOo0o
elif Ii1i1i1i1I1Ii == 11 :
 oOOoO0o0oO ( IiiiIIiIi1 , OOOOo0 , o0iiiI1I1iIIIi1 )
 if 65 - 65: Oo . iii1I1I % i11Ii11I1Ii1i * O0oo0OO0
elif Ii1i1i1i1I1Ii == 12 :
 Oo0O0 ( IiiiIIiIi1 , OOOOo0 , o0iiiI1I1iIIIi1 )
 if 38 - 38: Oo0ooO0oo0oO / i1OOooo0000ooo % O00oOoOoO0o0O
elif Ii1i1i1i1I1Ii == 13 :
 II1IiiIi1i ( IiiiIIiIi1 , OOOOo0 , o0iiiI1I1iIIIi1 )
 if 11 - 11: i1OOooo0000ooo - i11Ii11I1Ii1i + Oo - o0
 if 7 - 7: OOo000 - OOoO / Oo * ooo0Oo0 . i1OOooo0000ooo * i1OOooo0000ooo
 if 61 - 61: OOoO % OoOoo0 - O0oo0OO0 / O00oOoOoO0o0O
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
if 4 - 4: i1oOo0OoO - iIIIiiIIiiiIi % ooo0Oo0 - ooO * I1i1iI1i
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
